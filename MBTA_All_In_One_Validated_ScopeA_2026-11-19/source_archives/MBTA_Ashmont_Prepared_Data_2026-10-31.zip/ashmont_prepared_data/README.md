# Ashmont: prepared data and source audit

**Prepared:** October 31, 2026. **Team:** Alex Lim, Yun Ji Seo, Luran Wang.

This package processes the re-uploaded `MBTA_Ashmont_Project_Starter_2026-10-16 (1).zip`. It contains actual extracted records and computed scheduled baselines, not merely templates. No optimization was run. The scheduled results apply to the **supplied snapshot**; historical-feed reconciliation and operating-allowance validation remain open.

## Main findings

- The supplied GTFS produces 18 Route 22 terminal arrivals and 23 Route 23 terminal arrivals at Ashmont in [16:00,19:00) on October 15, 2026: 41 equally weighted opportunities, not observed passengers.
- Six editable Route 215 departures toward Quincy Center are 16:20, 16:50, 17:20, 17:50, 18:20, and 18:52. All 47 selected trips have block IDs.
- All 37 eligible onward departures for the service day are retained. Ten depart after 19:00: 19:20, 19:50, 20:20, 20:50, 21:20, 21:50, 22:40, 23:30, 24:15, and 25:00. The latter two are after midnight on the following calendar day.
- With an **assumed** 180-second passenger transfer allowance and readiness <= departure accepted, scheduled mean waiting is **810.7317 seconds (13.5122 minutes)**; maximum waiting is **1,800 seconds (30 minutes)**. Mean total elapsed transfer time, including the allowance, is **16.5122 minutes**. All 41 opportunities are served; two use the 19:20 departure. Fifteen have a wait of at most ten minutes.
- Route 22 mean waiting is 12.8889 minutes (18 opportunities); Route 23 mean waiting is 14 minutes (23 opportunities).
- The raw event extract contains **3,427 rows, 24 columns**, and service dates October 10–16. There are 456 missing estimated arrivals and 456 missing estimated departures. Missing telemetry is not treated as cancellation or on-time service.
- The full available event key has no duplicate rows. The coarser date/route/trip/stop/GTFS-sequence key has eight ambiguous groups comprising 16 rows. They are preserved separately, not averaged.
- October 13, 14, and 15 each have unique usable numeric-time records for the 41 fixed incoming opportunities and all 37 anchor onward departures, with matching schedule signatures. October 16 has matching schedule signatures but no afternoon observations; only six of the 37 onward departures have observations. October 10–12 are not complete matches to the anchor weekday timetable.

## Critical historical-feed distinction

The supplied feed reports version `Fall 2026, 2026-10-14T18:47:38+00:00, version D`, with declared feed dates October 7–December 12. Those declarations and calendar checks do not, alone, establish which corrected historical timetable should be used.

The official MBTA corrected archive index read on October 31 associates **October 14–19** with version `Fall 2026, 2026-10-21T20:52:18+00:00, version D`, at the archive URL ending `/20261014.zip`. It lists the supplied version against **October 7–8**. MBTA explains that archive date ranges may be adjusted and erroneous feeds replaced. LAMP separately documents a day-after-publication applicability convention. These are distinct provenance conventions, not a reason to silently rewrite the supplied data.

**Decision needed before final historical claims:** use a documented as-published snapshot study, or obtain and compare the corrected archive for retrospective analysis. The corrected binary file could not be acquired in this session, so no claim is made that the study-route times changed. All computed baseline results remain labeled snapshot-based.

Sources: [S2]–[S4] in `research/source_register.csv`. Six verbatim factual index rows were collected from the web-readable index into `research/official_archive_index_excerpt.csv`; this is not a downloaded replacement feed.

## Passenger transfer allowance

The feed has no 334-to-334 passenger transfer record. Stop 334 represents the Ashmont busway; it does not resolve individual bus berths. Existing transfer records to rail/trolley platforms are not direct evidence for the bus-to-bus allowance.

MBTA distinguishes minimum walking time and suggested transfer buffers; `min_transfer_time` is their sum. Do not add an already included buffer twice. The 2-, 3-, and 5-minute allowances below are study assumptions, not MBTA requirements.

| Transfer allowance | Mean wait after allowance | Maximum wait | Mean total elapsed transfer | Stranded |
|---|---:|---:|---:|---:|
| 2 minutes | 14.5122 min | 31 min | 16.5122 min | 0 |
| 3 minutes | 13.5122 min | 30 min | 16.5122 min | 0 |
| 5 minutes | 13.6585 min | 29 min | 18.6585 min | 0 |

A lower post-allowance wait does not necessarily mean a better transfer when comparing different allowances. Read total elapsed transfer time alongside waiting.

## Vehicle continuity: both ends matter

| Selected departure | Same-vehicle arrival at Ashmont | Ashmont scheduled gap | Quincy arrival | Following route / departure | Quincy scheduled gap |
|---|---|---:|---|---|---:|
| 16:20 | 16:15 | 5 min | 17:08 | 220 / 17:14 | 6 min |
| 16:50 | 16:45 | 5 min | 17:38 | 225 / 17:56 | 18 min |
| 17:20 | 17:15 | 5 min | 18:05 | 216 / 18:14 | 9 min |
| 17:50 | 17:45 | 5 min | 18:29 | 225 / 18:45 | 16 min |
| 18:20 | 18:15 | 5 min | 18:57 | 215 / 19:05 | 8 min |
| 18:52 | 18:45 | 7 min | 19:29 | 215 / 19:35 | 6 min |

Four successors require moving from Quincy Center Berth 3 to Berths 1, 2, or 4. All these stops share parent station `place-qnctr`, so the missing parameter is **within-terminal vehicle repositioning**, not evidence of a journey between separate stations. No duration is verified. Passenger walking pathways cannot establish bus repositioning time.

`vehicle_links.csv` contains all 12 directly relevant predecessor/successor links. `block_trip_endpoints.csv` includes all 39 active trips in the affected blocks. `gtfs_subset/relevant_complete_stop_times.csv` contains complete trajectories for 109 relevant trips (4,342 stop-time rows), including fixed neighboring trips on other routes.

The configured 180-second vehicle turnaround is a separate assumption from the 180-second passenger transfer allowance. With that vehicle assumption, five selected departures can advance by at most two minutes and the last by at most four minutes, before other constraints. Four upper bounds remain incomplete because repositioning is unspecified. `shift_bounds.csv` must **not** be used as if all six intervals were operationally approved.

The provisional observed Ashmont gap diagnostics include two October 15 gaps below 180 seconds (128 and 136 seconds), despite matching observed vehicle labels. This does not prove an operating violation: timestamps are estimates, the clock interpretation remains conditional, and 180 seconds is our assumption rather than a verified minimum. It shows why that assumption needs sensitivity analysis.

## Timestamp audit and Scope B restrictions

The uploaded Parquet schema marks datetime fields as **timezone-naive** (`isAdjustedToUTC=false`), unlike the UTC-aware fields documented in the current public dictionary. No timezone was invented or attached to the raw extract.

Across all 3,427 rows:

- The naive planned datetime, measured from the service-date midnight, is exactly **14,400 seconds earlier** than `plan_stop_departure_sam`.
- Every nonmissing estimated arrival/departure datetime agrees exactly with its corresponding numeric seconds field (2,971 rows each).
- Against the supplied feed's day-specific calendars, 3,423 event rows match; 3,417 have identical numeric planned departures. The six mismatches are on October 11 and are retained. Four other records do not match the supplied snapshot.
- All selected 47 events on October 15 have unique nonmissing observations and matching planned numeric times.

The package computes **diagnostic** offsets as observed numeric seconds minus matched GTFS seconds, under a stated common-local-service-day interpretation. Raw datetime subtraction is not used. Neither these offsets nor the candidate replay results establish a fully validated delay scenario until the original export convention is reconciled.

| Candidate observed day | Complete incoming cohort | Complete onward schedule | Conditional mean replay wait | Conditional maximum wait |
|---|---:|---:|---:|---:|
| Oct 13 | 41/41 | 37/37 | 14.5167 min | 31.9000 min |
| Oct 14 | 41/41 | 37/37 | 13.1870 min | 29.8667 min |
| Oct 15 | 41/41 | 37/37 | 16.4886 min | 42.7667 min |

These are diagnostic replays of the unchanged timetable, not optimization results, not validated typical/disrupted scenarios, and not estimates of broad reliability. They use a three-minute allowance and retain all 37 onward departures, including potentially delayed earlier trips. The fixed cohort is based on scheduled arrivals; delayed arrivals beyond 19:00 remain included.

Only Ashmont observations were uploaded. Quincy terminal arrival and following-trip departure observations are absent, so scenario-specific downstream vehicle feasibility cannot be established. Do not select training and test scenarios from individual shuffled rows; preserve complete days and reserve separate days when sufficient validated data exists.

## Files to start with

| File | Contents |
|---|---|
| `scope_a/incoming.csv` | 41 fixed incoming opportunities with trip IDs, clocks, and seconds |
| `scope_a/outgoing.csv` | All 37 onward departures; six marked adjustable |
| `scope_a/baseline_connections.csv` | Every scheduled connection and waiting calculation |
| `scope_a/baseline_transfer_sensitivity.csv` | 2/3/5-minute transfer-allowance cases |
| `scope_a/vehicle_chain_summary.csv` | Readable predecessor/selected/successor summary |
| `scope_a/vehicle_links.csv` | Direct vehicle continuity inputs and unresolved repositioning |
| `scope_a/headway_limits.csv` | Seven boundary-inclusive headway constraints; bounds are assumptions |
| `gtfs_subset/` | Relevant trips, complete trajectories, stops, routes, and calendars |
| `raw/ashmont_events_all_raw_fields.csv` | All 3,427 uploaded event rows, with all 24 fields retained |
| `event_audit/all_event_schedule_alignment.csv` | Rowwise joins, discrepancies, and conditional delay offsets |
| `event_audit/fixed_cohort_observation_panel.csv` | 546 day/anchor-event records; date-specific trip IDs and explicit missingness |
| `event_audit/fixed_cohort_daily_readiness.csv` | Coverage and non-readiness for certified scenarios |
| `event_audit/ashmont_vehicle_gap_diagnostics.csv` | 18 predecessor-to-departure diagnostics across three days |
| `research/source_register.csv` | Official sources, collected items, and failed acquisitions |
| `research/remaining_data_requirements.csv` | Exact missing fields and date scopes |
| `validation_checks.json` | Independent baseline checks |
| `file_manifest.csv` | Byte sizes and SHA-256 digests |

## What was and was not acquired online

Official archive-index metadata and source definitions were read and recorded. The updated recent-events binary, the corrected historical GTFS binary, and the annual LAMP feed-info binary were **not downloaded successfully**. Consequently **zero additional bus-event observations from the web** have been merged into the uploaded 3,427 rows. Do not interpret an acquisition failure here as evidence that the source does not exist publicly.

The package includes a downloader for reproducible retrieval in a network-enabled environment; it is a tool, not proof of an acquired dataset. Source URLs, including the corrected archive and recent bus-event file, are in the source register.

## Reproduce

Python 3.10+ is required for schedule preparation; event auditing also needs pandas and normally pyarrow. This environment lacked pyarrow and package downloads failed, so a narrow flat-Parquet reader was used for the supplied file. It supports only the observed PLAIN/dictionary V1 encodings and Snappy compression, rejects unsupported formats, and checks all column row counts, available min/max statistics, and null counts. Those checks are saved in `event_audit/parquet_decode_checks.json`.

From this directory, write to a fresh folder:

```bash
python scripts/prepare_scope_a.py \
  --input raw/MBTA_GTFS_2026-10-16.zip \
  --config config.json \
  --out rerun_scope_a
```

A return code of 2 with generated outputs is expected while unknown repositioning is flagged; inspect `audit.json`. This deliberately prevents treating incomplete operating inputs as verified.

To re-run event audits against the supplied `scope_a/` tables:

```bash
python scripts/audit_starter.py .
```

Additional readable outputs are in `scope_a/baseline_connections_readable.csv`; table units and caveats are in `data_dictionary.csv`. Supplemental vehicle and GTFS tables can be regenerated with `python scripts/enrich_tables.py .`.

The schedule tool's 17 synthetic tests passed. More importantly, all 41 baseline waits and all three sensitivity summaries were recomputed using an independent exhaustive-minimum calculation and agree. Synthetic tests alone are not evidence of historical correctness.

## Boundaries

This is a data-preparation and validation aid, not a finished course submission or an operational schedule recommendation. No passenger counts, certified operating minimums, fresh observations, or optimized results have been invented. Preserve attribution and review the analysis as a team before using it in coursework.
