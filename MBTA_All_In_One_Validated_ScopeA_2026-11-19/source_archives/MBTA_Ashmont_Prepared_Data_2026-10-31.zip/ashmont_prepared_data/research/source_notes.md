# Official sources reviewed on October 31, 2026

1. **MBTA corrected GTFS archive index** — https://cdn.mbta.com/archive/archived_feeds.txt
   Six relevant rows are preserved in `official_archive_index_excerpt.csv`. The index maps the project date to a different feed version from the uploaded snapshot. Replacement ZIP data were not acquired.
2. **MBTA archive documentation** — https://raw.githubusercontent.com/mbta/gtfs-documentation/master/reference/gtfs-archive.md
   The curated archive can adjust recommended validity dates and replace feeds with corrections. The index alone does not reveal which individual route schedules changed.
3. **LAMP public data and archive instructions** — https://performancedata.mbta.com/
   Annual Parquet records use `gtfs_active_date` and `gtfs_end_date`; the documented applicability convention is the day after publication. Do not conflate this convention with the corrected archive's recommended historical date ranges.
4. **MBTA GTFS implementation** — https://raw.githubusercontent.com/mbta/gtfs-documentation/master/reference/gtfs.md
   Walking time and suggested buffer are distinct. Block IDs alone do not authorize passengers to remain aboard through a linked trip. Platform-level stop metadata do not determine vehicle movement time.
5. **LAMP event dictionary** — https://raw.githubusercontent.com/mbta/lamp/main/Data_Dictionary.md
   Stop events are estimates and keys include vehicle/pullout distinctions; missing data and timezone definitions require review. The uploaded file's naive datetime schema differs from current documented UTC-aware fields.
6. **Apache Parquet specification** — https://raw.githubusercontent.com/apache/parquet-format/master/src/main/thrift/parquet.thrift
   Used to decode the uploaded flat Parquet file when the normal Arrow dependency was unavailable. Metadata and page/column statistics were checked, not bypassed.

No unrelated weather, ridership proxies, live predictions, or old-year operating records were merged into the study. They would not resolve the identified schedule and event-clock issues directly.
