#!/usr/bin/env python3
"""Audit supplied Ashmont data, preserving raw fields. No timetable optimization.
Observed delay/wait outputs are DIAGNOSTIC, not certified delay scenarios.
Run after prepare_scope_a.py. Uses a strict fallback if pyarrow is unavailable.
"""
from pathlib import Path
import sys, json, csv, hashlib, bisect
from datetime import date, datetime, timezone
from zipfile import ZipFile
import pandas as pd
from prepare_scope_a import Feed, active_services, gtfs_seconds, clock

def read_events(path: Path):
    try:
        import pyarrow.parquet as pq
        table=pq.read_table(path)
        frame=table.to_pandas()
        for c in frame.columns:
            if c.endswith('_dt') or c=='service_date':
                frame[c]=frame[c].astype(str).replace({'NaT':None,'None':None})
        return frame, {'reader':'pyarrow','schema':str(table.schema),'row_count':len(frame)}
    except ImportError:
        from parquet_fallback import read_flat_parquet
        cols,checks=read_flat_parquet(path)
        return pd.DataFrame(cols),checks

def main(root: Path):
    raw=root/'raw';out=root/'event_audit';out.mkdir(exist_ok=True)
    d,decode=read_events(raw/'Ashmont_bus_events_2026-10-16.parquet')
    for c in ['trip_id','route_id','stop_id','block_id','service_id','vehicle_label','tm_pullout_id']:
        d[c]=d[c].astype(str)
    for c in d.columns:
        if c.endswith(('_sam','_seconds')) or c in ['direction_id','gtfs_stop_sequence','stop_sequence']:
            d[c]=pd.to_numeric(d[c],errors='coerce').astype('Int64')
    d.to_csv(raw/'ashmont_events_all_raw_fields.csv',index=False)
    (out/'parquet_decode_checks.json').write_text(json.dumps(decode,indent=2))
    # Check one-to-one raw-record key separately from the coarser trip-stop key.
    fullkey=['service_date','route_id','trip_id','stop_sequence','tm_pullout_id','vehicle_label']
    coarse=['service_date','route_id','trip_id','stop_id','gtfs_stop_sequence']
    full_dup=d.duplicated(fullkey,keep=False)
    dup=d.duplicated(coarse,keep=False)
    d.loc[dup].to_csv(out/'ambiguous_trip_stop_records.csv',index=False)
    nulls=pd.DataFrame({'field':d.columns,'missing_rows':d.isna().sum().values})
    nulls['missing_fraction']=nulls.missing_rows/len(d)
    nulls.to_csv(out/'missingness.csv',index=False)
    daily=d.groupby(['service_date','route_id'],as_index=False).agg(
        records=('trip_id','size'),estimated_arrival_present=('stop_arrival_seconds','count'),
        estimated_departure_present=('stop_departure_seconds','count'),unique_trip_ids=('trip_id','nunique'))
    daily.to_csv(out/'daily_raw_coverage.csv',index=False)
    temporal=[]
    for a,b in [('plan_stop_departure_dt','plan_stop_departure_sam'),
                ('stop_arrival_dt','stop_arrival_seconds'),('stop_departure_dt','stop_departure_seconds')]:
        delta=(pd.to_datetime(d[a])-pd.to_datetime(d.service_date)).dt.total_seconds()-d[b]
        for value,n in delta.value_counts(dropna=False).items():
            temporal.append({'datetime_field':a,'seconds_field':b,'datetime_minus_seconds':None if pd.isna(value) else value,'records':int(n)})
    pd.DataFrame(temporal).to_csv(out/'timestamp_consistency.csv',index=False)
    # Match every observation date to calendars in THE SUPPLIED SNAPSHOT ONLY.
    f=Feed(raw/'MBTA_GTFS_2026-10-16.zip')
    calendar=list(f.rows('calendar.txt'));exceptions=list(f.rows('calendar_dates.txt'))
    trips={t['trip_id']:t for t in f.rows('trips.txt') if t['route_id'] in ['22','23','215']}
    station=[]
    for r in f.rows('stop_times.txt'):
        if r['stop_id']=='334' and r['trip_id'] in trips:
            t=trips[r['trip_id']]
            station.append(dict(trip_id=r['trip_id'],stop_id='334',route_id=t['route_id'],
                gtfs_stop_sequence=int(r['stop_sequence']),schedule_service_id=t['service_id'],
                schedule_block_id=t.get('block_id',''),scheduled_arrival_sec=gtfs_seconds(r['arrival_time']),
                scheduled_departure_sec=gtfs_seconds(r['departure_time']),schedule_headsign=t['trip_headsign'],
                schedule_direction_id=t['direction_id'],pickup_type=r.get('pickup_type','0'),drop_off_type=r.get('drop_off_type','0')))
    f.close();st=pd.DataFrame(station)
    schedules=[]
    for day in sorted(d.service_date.unique()):
        s=st[st.schedule_service_id.isin(active_services(calendar,exceptions,day))].copy();s['service_date']=day;schedules.append(s)
    sched=pd.concat(schedules,ignore_index=True)
    keys=['service_date','route_id','trip_id','stop_id','gtfs_stop_sequence']
    assert not sched.duplicated(keys).any()
    m=d.merge(sched,on=keys,how='left',validate='many_to_one',indicator=True)
    m['match_count']=m.groupby(keys).trip_id.transform('size')
    m['planned_numeric_minus_gtfs_sec']=m.plan_stop_departure_sam-m.scheduled_departure_sec
    m['diagnostic_arrival_delay_sec']=m.stop_arrival_seconds-m.scheduled_arrival_sec
    m['diagnostic_departure_delay_sec']=m.stop_departure_seconds-m.scheduled_departure_sec
    m['clock_status']='LOCAL_NUMERIC_INTERPRETATION_PROVISIONAL_RAW_DATETIME_CONVENTION_UNRESOLVED'
    m['historical_feed_status']='SUPPLIED_SNAPSHOT_CALENDARS_ONLY_NOT_DATE_ARCHIVE_RECONCILED'
    m.to_csv(out/'all_event_schedule_alignment.csv',index=False)
    m[m._merge!='both'].to_csv(out/'events_not_matched_to_snapshot.csv',index=False)
    # Fixed 15-Oct cohort is kept in all comparisons. Do not fill missing events.
    inc=pd.read_csv(root/'scope_a/incoming.csv',dtype={'trip_id':str,'route_id':str,'stop_id':str})
    onward=pd.read_csv(root/'scope_a/outgoing.csv',dtype={'trip_id':str,'route_id':str,'stop_id':str})
    wanted_out=onward.copy()  # all 37: a very late earlier bus can still be eligible
    candidates=[];daily_ready=[];connections=[];day_scores=[]
    for day in sorted(d.service_date.unique()):
        dd=d[d.service_date==day]
        schedule_rows=sched[sched.service_date==day]
        schedule_day=schedule_rows.set_index(['route_id','trip_id','gtfs_stop_sequence'])
        day_items=[]
        for role,rows,event_field,scheduled_field in [('arrival',inc,'stop_arrival_seconds','arrival_sec'),('departure',wanted_out,'stop_departure_seconds','departure_sec')]:
            for row in rows.to_dict('records'):
                event_col='scheduled_arrival_sec' if role=='arrival' else 'scheduled_departure_sec'
                daily_schedule=schedule_rows[(schedule_rows.route_id==str(row['route_id']))&(schedule_rows.gtfs_stop_sequence==int(row['stop_sequence']))&(schedule_rows[event_col]==int(row[scheduled_field]))&(schedule_rows.schedule_headsign==row['trip_headsign'])&(schedule_rows.schedule_direction_id==str(row['direction_id']))]
                daily_tid=str(daily_schedule.iloc[0].trip_id) if len(daily_schedule)==1 else ''
                subset=dd[(dd.trip_id==daily_tid)&(dd.route_id==str(row['route_id']))&(dd.gtfs_stop_sequence==int(row['stop_sequence']))]
                key=(str(row['route_id']),daily_tid,int(row['stop_sequence']))
                active=key in schedule_day.index
                rec=subset.iloc[0] if len(subset)==1 else None
                observed=None if rec is None or pd.isna(rec[event_field]) else int(rec[event_field])
                anchor_time=row[scheduled_field]
                if active:
                    anchor_day_time=schedule_day.loc[key,'scheduled_arrival_sec' if role=='arrival' else 'scheduled_departure_sec']
                else:anchor_day_time=None
                compatible=active and anchor_day_time==anchor_time
                plan_ok=rec is not None and int(rec.plan_stop_departure_sam)==int(row['departure_sec'])
                x=dict(service_date=day,role=role,route_id=row['route_id'],trip_id=row['trip_id'],daily_trip_id=daily_tid,stop_id='334',
                    gtfs_stop_sequence=int(row['stop_sequence']),scheduled_event_sec=int(anchor_time),
                    scheduled_clock=clock(anchor_time),raw_candidate_count=len(subset),scheduled_in_snapshot_on_date=active,
                    matches_anchor_time=compatible,planned_numeric_matches_snapshot=plan_ok,
                    observed_event_sec=observed,observed_clock=None if observed is None else clock(observed),
                    diagnostic_delay_sec=None if observed is None else observed-int(anchor_time),
                    is_adjustable=int(row.get('is_adjustable',0)),
                    status='PROVISIONAL_MATCHED' if observed is not None and compatible and plan_ok else 'MISSING_AMBIGUOUS_OR_SCHEDULE_MISMATCH')
                day_items.append(x);candidates.append(x)
        incoming=[x for x in day_items if x['role']=='arrival'];outgoing=[x for x in day_items if x['role']=='departure']
        arr_good=[x for x in incoming if x['status']=='PROVISIONAL_MATCHED']
        dep_good=[x for x in outgoing if x['status']=='PROVISIONAL_MATCHED']
        complete=len(arr_good)==len(inc) and len(dep_good)==len(wanted_out)
        daily_ready.append(dict(service_date=day,anchor_opportunities=len(inc),incoming_matched_and_observed=len(arr_good),
            editable_departures_required=6,editable_departures_matched_and_observed=sum(x['is_adjustable'] for x in dep_good),
            all_day_departures_required=len(wanted_out),all_day_departures_matched_and_observed=len(dep_good),
            incoming_schedule_signature_matches=sum(x['matches_anchor_time'] for x in incoming),
            all_day_departure_schedule_signature_matches=sum(x['matches_anchor_time'] for x in outgoing),
            complete_fixed_cohort_and_onward=complete,ready_for_certified_scope_b=False))
        if complete:
            od=sorted(dep_good,key=lambda x:(x['observed_event_sec'],x['trip_id']))
            times=[x['observed_event_sec'] for x in od];waits=[]
            for x in arr_good:
                ready=x['observed_event_sec']+180;j=bisect.bisect_left(times,ready)
                dep=od[j] if j<len(od) else None
                wait=None if dep is None else dep['observed_event_sec']-ready
                waits.append(wait)
                connections.append(dict(service_date=day,incoming_trip_id=x['trip_id'],route_id=x['route_id'],
                    observed_arrival_sec=x['observed_event_sec'],ready_sec=ready,outgoing_trip_id=None if dep is None else dep['trip_id'],
                    observed_departure_sec=None if dep is None else dep['observed_event_sec'],diagnostic_wait_sec=wait,
                    interpretation='DIAGNOSTIC_REPLAY_NOT_VALIDATED_SCENARIO'))
            day_scores.append(dict(service_date=day,opportunities=len(waits),stranded=sum(w is None for w in waits),
                mean_diagnostic_wait_min=sum(w for w in waits if w is not None)/sum(w is not None for w in waits)/60,
                max_diagnostic_wait_min=max(w for w in waits if w is not None)/60,
                interpretation='NUMERIC_TIME_INTERPRETATION_ONLY; HISTORICAL_FEED_AND_VEHICLE_OPERATIONS_UNRESOLVED'))
    pd.DataFrame(candidates).to_csv(out/'fixed_cohort_observation_panel.csv',index=False)
    pd.DataFrame(daily_ready).to_csv(out/'fixed_cohort_daily_readiness.csv',index=False)
    pd.DataFrame(connections).to_csv(out/'diagnostic_replay_connections.csv',index=False)
    pd.DataFrame(day_scores).to_csv(out/'diagnostic_replay_summary.csv',index=False)
    # 15 October metrics only for matched relevant events; don't infer other days.
    panel=pd.DataFrame(candidates)
    relevant=panel[(panel.service_date=='2026-10-15')&((panel.role=='arrival')|(panel.is_adjustable==1))]
    relevant.to_csv(out/'selected_47_events_20261015.csv',index=False)
    summary={'raw_rows':len(d),'columns':len(d.columns),'dates':sorted(d.service_date.unique()),
             'missing_estimated_arrivals':int(d.stop_arrival_seconds.isna().sum()),
             'missing_estimated_departures':int(d.stop_departure_seconds.isna().sum()),
             'duplicate_fullkey_rows':int(full_dup.sum()),'ambiguous_coarsekey_rows':int(dup.sum()),
             'ambiguous_coarsekey_groups':len(d.loc[dup,coarse].drop_duplicates()),
             'matched_to_same_snapshot_calendars':int((m._merge=='both').sum()),
             'planned_numeric_matching_gtfs':int((m.planned_numeric_minus_gtfs_sec==0).sum()),
             'estimated_departure_before_arrival':int((d.stop_departure_seconds<d.stop_arrival_seconds).sum()),
             'fixed_cohort_day_readiness':daily_ready,
             'restrictions':['No timezone adjustment was applied to raw datetime fields.',
                             'Numeric delay and replay outputs are provisional, not validated scenarios.',
                             'No Quincy Center endpoint observations exist in this Ashmont-only extract.',
                             'The same uploaded snapshot is used for date calendars; older dates are not historically reconciled.',
                             'Missing telemetry is not treated as cancellation or on-time service.']}
    (out/'summary.json').write_text(json.dumps(summary,indent=2,default=str))
    print(json.dumps(summary,indent=2,default=str));print(pd.DataFrame(day_scores).to_string(index=False))
if __name__=='__main__':
    main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
