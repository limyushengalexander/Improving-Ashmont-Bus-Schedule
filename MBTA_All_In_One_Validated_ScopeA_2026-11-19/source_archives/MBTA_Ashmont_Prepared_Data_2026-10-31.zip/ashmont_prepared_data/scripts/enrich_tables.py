"""Regenerate core supplemental tables from the prepared schedule, raw feed, and event CSV.
No new assumptions are resolved; Quincy repositioning remains unverified.
"""
from pathlib import Path
from zipfile import ZipFile
import pandas as pd
import sys

def main(p):
    links=pd.read_csv(p/'scope_a/vehicle_links.csv',dtype={'predecessor_trip_id':str,'successor_trip_id':str,'block_id':str})
    outgoing=pd.read_csv(p/'scope_a/outgoing.csv',dtype={'trip_id':str})
    endpoints=pd.read_csv(p/'scope_a/block_trip_endpoints.csv',dtype={'trip_id':str,'route_id':str})
    inc=pd.read_csv(p/'scope_a/incoming.csv',dtype={'trip_id':str})
    recs=[]
    clock=lambda s:f'{int(s)//3600:02d}:{int(s)%3600//60:02d}'
    for r in outgoing[outgoing.is_adjustable==1].to_dict('records'):
        pre=links[links.successor_trip_id==r['trip_id']].iloc[0]
        nxt=links[links.predecessor_trip_id==r['trip_id']].iloc[0]
        recs.append(dict(trip_id=r['trip_id'],departure_time=r['departure_time'],block_id=r['block_id'],
            previous_trip_id=pre.predecessor_trip_id,previous_arrival_time=clock(pre.predecessor_end_sec),
            ashmt_scheduled_gap_min=pre.scheduled_gap_sec/60,quincy_arrival_time=clock(nxt.predecessor_end_sec),
            following_trip_id=nxt.successor_trip_id,following_route_id=str(nxt.successor_route_id),
            following_departure_time=clock(nxt.successor_start_sec),quincy_scheduled_gap_min=nxt.scheduled_gap_sec/60,
            end_berth_stop_id=str(nxt.predecessor_end_stop_id),following_berth_stop_id=str(nxt.successor_start_stop_id),
            conditional_lower_shift_min=max(-5,3-pre.scheduled_gap_sec/60),
            conditional_upper_shift_min_if_no_reposition=min(5,nxt.scheduled_gap_sec/60-3),
            reposition_allowance_verified=nxt.predecessor_end_stop_id==nxt.successor_start_stop_id,
            minimum_turnaround_assumption_min=3))
    pd.DataFrame(recs).to_csv(p/'scope_a/vehicle_chain_summary.csv',index=False)
    b=pd.read_csv(p/'scope_a/baseline_connections.csv')
    b.groupby('route_id',as_index=False).agg(opportunities=('route_id','size'),mean_wait_sec=('platform_wait_sec','mean'),max_wait_sec=('platform_wait_sec','max'),mean_total_sec=('total_transfer_sec','mean')).to_csv(p/'scope_a/baseline_by_route.csv',index=False)
    blocks=set(endpoints.trip_id);use=blocks|set(inc.trip_id)|set(outgoing.trip_id)
    stage=p/'gtfs_subset';stage.mkdir(exist_ok=True)
    with ZipFile(p/'raw/MBTA_GTFS_2026-10-16.zip') as z:
        trips=pd.read_csv(z.open('trips.txt'),dtype=str,keep_default_na=False)
        trips[trips.trip_id.isin(blocks)].to_csv(stage/'affected_block_trips.csv',index=False)
        rel=trips[trips.trip_id.isin(use)];rel.to_csv(stage/'relevant_trips.csv',index=False)
        parts=[]
        for c in pd.read_csv(z.open('stop_times.txt'),dtype=str,chunksize=100000,keep_default_na=False):
            q=c[c.trip_id.isin(use)]
            if len(q):parts.append(q)
        times=pd.concat(parts,ignore_index=True);times.to_csv(stage/'relevant_complete_stop_times.csv',index=False)
        for name in ['calendar.txt','calendar_dates.txt','calendar_attributes.txt']:
            f=pd.read_csv(z.open(name),dtype=str,keep_default_na=False)
            f[f.service_id.isin(rel.service_id)].to_csv(stage/(name[:-4]+'.csv'),index=False)
        stops=pd.read_csv(z.open('stops.txt'),dtype=str,keep_default_na=False)
        chosen=stops[stops.stop_id.isin(times.stop_id)]
        pd.concat([chosen,stops[stops.stop_id.isin(chosen.parent_station)]],ignore_index=True).drop_duplicates('stop_id').to_csv(stage/'relevant_stops.csv',index=False)
        stops[stops.stop_id.isin(['334','32001','32002','32003','32004'])].to_csv(p/'scope_a/terminal_stops.csv',index=False)
        routes=pd.read_csv(z.open('routes.txt'),dtype=str,keep_default_na=False)
        routes[routes.route_id.isin(rel.route_id)].to_csv(stage/'relevant_routes.csv',index=False)
    d=pd.read_csv(p/'raw/ashmont_events_all_raw_fields.csv',dtype={'trip_id':str,'vehicle_label':str})
    obs=[]
    for day in ['2026-10-13','2026-10-14','2026-10-15']:
        dd=d[d.service_date==day]
        for r in recs:
            a=dd[(dd.trip_id==r['previous_trip_id'])&(dd.point_type=='end')]
            b=dd[(dd.trip_id==r['trip_id'])&(dd.point_type=='start')]
            ok=len(a)==len(b)==1
            x=dict(service_date=day,selected_trip_id=r['trip_id'],scheduled_departure=r['departure_time'],predecessor_trip_id=r['previous_trip_id'],match_unique=ok)
            if ok:
                gap=float(b.iloc[0].stop_departure_seconds-a.iloc[0].stop_arrival_seconds)
                x.update(same_observed_vehicle=a.iloc[0].vehicle_label==b.iloc[0].vehicle_label,diagnostic_observed_gap_sec=gap,violates_assumed_180_second_gap=gap<180,predecessor_arrival_observed_sec=a.iloc[0].stop_arrival_seconds,selected_departure_observed_sec=b.iloc[0].stop_departure_seconds)
            obs.append(x)
    pd.DataFrame(obs).to_csv(p/'event_audit/ashmont_vehicle_gap_diagnostics.csv',index=False)
if __name__=='__main__':main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
