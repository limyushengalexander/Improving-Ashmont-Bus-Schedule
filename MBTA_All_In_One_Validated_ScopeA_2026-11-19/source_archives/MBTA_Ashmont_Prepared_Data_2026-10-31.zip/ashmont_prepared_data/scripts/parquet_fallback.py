from thrift.protocol.TCompactProtocol import TCompactProtocol
from thrift.transport.TTransport import TMemoryBuffer
from thrift.Thrift import TType
import struct,json

def read_val(p,t):
 if t==TType.STRUCT:
  out={};p.readStructBegin()
  while True:
   _,t2,f=p.readFieldBegin()
   if t2==TType.STOP:break
   out[f]=read_val(p,t2);p.readFieldEnd()
  p.readStructEnd();return out
 if t in [TType.LIST,TType.SET]:
  typ,n=p.readListBegin();out=[read_val(p,typ) for _ in range(n)];p.readListEnd();return out
 if t==TType.MAP:
  kt,vt,n=p.readMapBegin();out={read_val(p,kt):read_val(p,vt) for _ in range(n)};p.readMapEnd();return out
 return {TType.BOOL:p.readBool,TType.BYTE:p.readByte,TType.I16:p.readI16,TType.I32:p.readI32,TType.I64:p.readI64,TType.DOUBLE:p.readDouble,TType.STRING:p.readBinary}[t]()
def read_struct(data):
 tr=TMemoryBuffer(data);p=TCompactProtocol(tr);o=read_val(p,TType.STRUCT);return o,tr.cstringio_buf.tell()
# Narrow fallback reader: flat scalar Parquet, PLAIN / dictionary, V1 data pages.
# Uses the Apache Thrift compact protocol and system libsnappy; rejects unsupported encodings.
def _varint(b,p):
 v=0;s=0
 while True:
  x=b[p];p+=1;v|=(x&127)<<s
  if x<128:return v,p
  s+=7
  if s>64:raise ValueError('Invalid varint')
def _hybrid(b,width,n):
 vals=[];p=0;mask=(1<<width)-1
 while len(vals)<n:
  h,p=_varint(b,p)
  if h==0:raise ValueError('Zero RLE header')
  if h&1:
   count=(h>>1)*8;size=(count*width+7)//8
   chunk=int.from_bytes(b[p:p+size],'little');p+=size
   vals.extend((chunk>>(i*width))&mask for i in range(count))
  else:
   count=h>>1;size=(width+7)//8;x=int.from_bytes(b[p:p+size],'little');p+=size;vals.extend([x]*count)
 return vals[:n],p

def _plain(b,typ,n):
 if typ==0:return [bool((b[i//8]>>(i%8))&1) for i in range(n)]
 if typ in [1,2,4,5]:
  fmt={1:'i',2:'q',4:'f',5:'d'}[typ];return list(struct.unpack_from('<'+fmt*n,b))
 if typ==6:
  vals=[];p=0
  for _ in range(n):
   size=struct.unpack_from('<I',b,p)[0];p+=4;vals.append(b[p:p+size].decode('utf8'));p+=size
  return vals
 raise NotImplementedError(f'Physical type {typ}')

def _decompress(b,codec,size):
 if codec==0:return b
 if codec!=1:raise NotImplementedError(f'Codec {codec}')
 import ctypes,ctypes.util
 lib=ctypes.CDLL(ctypes.util.find_library('snappy'))
 lib.snappy_uncompress.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t)]
 dst=ctypes.create_string_buffer(size);n=ctypes.c_size_t(size)
 status=lib.snappy_uncompress(b,len(b),dst,ctypes.byref(n))
 if status!=0 or n.value!=size:raise ValueError('Snappy integrity failure')
 return dst.raw

def read_flat_parquet(path):
 import datetime,collections
 data=open(path,'rb').read()
 if data[:4]!=b'PAR1' or data[-4:]!=b'PAR1':raise ValueError('Invalid file magic')
 n=struct.unpack('<I',data[-8:-4])[0];meta,_=read_struct(data[-8-n:-8])
 schema={s[4].decode():s for s in meta[2][1:]};out={k:[] for k in schema};checks=[]
 for rg in meta[4]:
  for col in rg[1]:
   c=col[3];name=c[3][0].decode();s=schema[name]
   if len(c[3])!=1 or s.get(3,0)==2:raise NotImplementedError('Nested/repeated schema')
   offset=c.get(11,c[9]);end=offset+c[7];values=[];dictionary=None
   while offset<end and len(values)<c[5]:
    ph,sz=read_struct(data[offset:]);offset+=sz;raw=data[offset:offset+ph[3]];offset+=ph[3]
    body=_decompress(raw,c[4],ph[2])
    if ph[1]==2:
     if ph[7][2]!=0:raise NotImplementedError('Non-PLAIN dictionary')
     dictionary=_plain(body,c[1],ph[7][1]);continue
    if ph[1]!=0:raise NotImplementedError(f'Page type {ph[1]}')
    h=ph[5];count=h[1];p=0
    if s.get(3,0)==1:
     if h[3]!=3:raise NotImplementedError('Definition encoding')
     length=struct.unpack_from('<I',body,p)[0];p+=4
     definitions,used=_hybrid(body[p:p+length],1,count);p+=length
    else:definitions=[1]*count
    nonnull=sum(definitions)
    if h[2]==0:payload=_plain(body[p:],c[1],nonnull)
    elif h[2] in [2,8]:
     if dictionary is None:raise ValueError('Missing dictionary')
     indices,used=_hybrid(body[p+1:],body[p],nonnull) if nonnull else ([],0)
     payload=[dictionary[i] for i in indices]
    else:raise NotImplementedError(f'Value encoding {h[2]}')
    it=iter(payload);chunk=[next(it) if d else None for d in definitions];values.extend(chunk)
    stats=h.get(5,{})
    if 3 in stats and stats[3]!=chunk.count(None):raise ValueError('Page null count mismatch')
   if len(values)!=rg[3] or len(values)!=c[5]:raise ValueError('Row count mismatch')
   stats=c.get(12,{})
   if 3 in stats and stats[3]!=values.count(None):raise ValueError('Column null count mismatch')
   nonnull=[v for v in values if v is not None]
   for fid,fn in [(5,max),(6,min)]:
    if fid in stats and nonnull:
     bound=_plain(stats[fid],c[1],1)[0] if c[1]!=6 else stats[fid].decode()
     if fn(nonnull)!=bound:raise ValueError(f'{name} min/max statistics mismatch')
   checks.append({'column':name,'rows':len(values),'nulls':values.count(None),'statistics_checks_passed':True})
   if s.get(6)==6:
    values=[None if x is None else (datetime.date(1970,1,1)+datetime.timedelta(days=x)).isoformat() for x in values]
   if s.get(6) in (9,10):
    factor=1000 if s[6]==9 else 1
    values=[None if x is None else (datetime.datetime(1970,1,1)+datetime.timedelta(microseconds=x*factor)).isoformat(sep=' ') for x in values]
   out[name].extend(values)
 assert all(len(x)==meta[3] for x in out.values())
 return out,{'row_count':meta[3],'schema':{k:{str(j):str(v) for j,v in s.items()} for k,s in schema.items()},'checks':checks,'writer':meta.get(6,b'').decode(),'limitation':'Narrow reader; all column min/max/null/row-count statistics checked. No timezone added to naive timestamps.'}
