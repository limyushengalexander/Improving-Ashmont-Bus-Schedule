# 6.C57: MBTA bus timetable coordination

Prepared 16 October 2026. This is an optimization study. No application development is required.

## Recommended pilot

Study transfers at Ashmont from Routes 22 and 23 arriving from the Ruggles direction to Route 215 departing toward Quincy Center. Keep the incoming routes fixed and retime selected Route 215 trips. This is a deliberately directional study; it does not represent all transfers at Ashmont.

Use Thursday 15 October 2026, with incoming trips scheduled to arrive from 16:00 inclusive to 19:00 exclusive (America/New_York). Retain onward services after 19:00 and the preceding/following vehicle-block trips. Select the editable departure window separately from the arrival cohort. Do not classify a transfer as stranded just because it crosses the analysis window.

Inspection of the downloaded GTFS feed found 18 Route 22 arrivals, 23 Route 23 arrivals, and six Route 215 departures in this window. All 47 trip records have nonempty block_id values. Route 215 departures are 16:20, 16:50, 17:20, 17:50, 18:20, and 18:52. Their corresponding same-block arrivals at Ashmont are 16:15, 16:45, 17:15, 17:45, 18:15, and 18:45. These scheduled gaps are evidence of available layover, not an established minimum operating requirement.

Route 240 was screened but not selected initially because its afternoon departures have multiple destination patterns. Route 215 provides a simpler initial onward service. This choice is based on tractability, not demonstrated transfer demand or an exhaustive ranking of all interchanges.

## Refined decision problem

How much can small changes to selected Route 215 departure times reduce waiting for specified transfers from Routes 22 and 23 at Ashmont, while preserving trip counts, scheduled running times, service spacing, and known vehicle continuity?

- Decision: a time shift for each editable Route 215 trip. Shift its complete stop-time trajectory consistently, rather than changing the first stop while leaving its endpoint unchanged.
- Initial adjustment bound: +/-5 minutes, an explicit study assumption. Vehicle and service constraints may make the feasible interval smaller or asymmetric.
- Fixed inputs: incoming schedules, route patterns, trip counts, and scheduled running times.
- Transfer opportunity: one incoming trip paired with the Route 215 service needed to reach a specified destination served by the eligible departures. The 41 incoming trips define 41 equally weighted opportunities. These are not 41 observed passengers.
- Transfer allowance: verify station walking and boarding requirements. The feed contains no 334-to-334 transfer record; the shared GTFS stop ID does not establish zero walking time. A provisional allowance must be labelled as assumed.
- Waiting: time from being ready to board after the transfer allowance until the first usable onward departure. Report total elapsed transfer time separately if desired.
- Missed bus: wait for the next eligible bus. No remaining service: explicit penalty and separate stranded count. Keep the denominator fixed across all schedules and scenarios.
- Constraints: departure-shift bounds, ordering and service-spacing bounds, previous/next vehicle-block links including trips on other routes, and explicit turnaround assumptions. Include boundary trips outside the optimized window. Nonempty block IDs do not establish complete driver or operating feasibility.
- Tie-breaking: among equally good waiting-time solutions, minimize total absolute timetable shift.

## Scope A

Minimize average transfer waiting cost under scheduled operation. Use a deterministic mixed-integer linear model in Julia/JuMP. Compare existing, feasible greedy-adjustment, and optimized timetables under identical assumptions.

## Scope B

Choose one common timetable minimizing the largest average transfer waiting cost among three scenarios: scheduled operation, a representative observed pattern, and a more disrupted observed pattern. Transfer assignments and resulting waits can differ by scenario; planned departure shifts cannot.

Implement min z subject to z >= average waiting cost in scenario s, for all three scenarios. This minimizes the worst scenario average, not the longest individual passenger wait. If stranded penalties are active, call the objective waiting cost rather than pure minutes of waiting.

Construct observed scenarios using matched complete weekday patterns within a consistent schedule period. Select representative and disrupted days by a stated rule applied before optimization. Preserve relative arrival/departure variation across routes instead of shifting all buses equally. Use separate evaluation days if enough observations exist. Hypothetical stress tests are a fallback and must not be called observed scenarios. Check vehicle availability under scenario delays or explicitly describe the scenarios as a limited replay evaluation; delay offsets alone do not guarantee feasible operations.

## Data snapshot

- MBTA_GTFS_2026-10-16.zip: unmodified download from https://cdn.mbta.com/MBTA_GTFS.zip.
- Feed version: Fall 2026, 2026-10-14T18:47:38+00:00, version D. Declared feed dates: 2026-10-07 through 2026-12-12. Operating trips were selected with calendar and date exceptions, not feed dates alone.
- Ashmont_bus_events_2026-10-16.parquet: selected columns and rows from https://performancedata.mbta.com/lamp/tableau/bus/LAMP_RECENT_Bus_Events.parquet, restricted to stop_id 334 and routes 22, 23, 215. Contains 10–16 October 2026; the last day is incomplete. Missing event timestamps occur. This is a raw extract, not a cleaned delay dataset.
- The full recent file had 2,374,925 records and was approximately 170 MB. The snapshot contains only the relevant Ashmont extract.
- Documentation: https://github.com/mbta/lamp/blob/main/Data_Dictionary.md and https://github.com/mbta/gtfs-documentation/blob/master/reference/gtfs.md.
- Historical schedule archive: https://performancedata.mbta.com/. Match each observation date to the applicable published feed. Do not assume that the October 14 feed correctly describes every earlier date in the extract.

For 15 October, all 41 selected incoming trips and six outgoing trips matched bus-event records by route and trip ID, with nonmissing estimated arrival/departure timestamps. This establishes event coverage for that sample, not validated delays.

Timestamp validation is outstanding. In inspected records, plan_stop_departure_dt differed by four hours from the matched GTFS clock time, while plan_stop_departure_sam numerically matched GTFS seconds after midnight. Do not subtract raw datetime columns or apply an automatic timezone correction without resolving their actual conventions against the source. Retain original fields and document the conversion used.

## Evaluation and immediate next work

First reconstruct baseline transfers and vehicle chains, then confirm transfer allowance and operating assumptions. Solve Scope A before committing to the observed-data extension. Confirm that spacing and vehicle constraints create interacting choices; more scenarios alone do not fix an independently solvable retiming problem.

Report average waiting, long waits, connection success under a predeclared threshold, stranded opportunities, total/max shift, runtime, solver status and gap. For Scope B, report every scenario mean and their maximum. Claims apply to modelled transfer opportunities and the stated constraints; no verified transfer passenger counts or total passenger-hour savings are available.

This package establishes a feasible schedule-data starting point. It does not contain an optimized timetable, a validated delay model, or an operational recommendation for deployment.
