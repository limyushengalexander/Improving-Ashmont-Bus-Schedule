# Ashmont timetable-coordination research and data-preparation kit

**Team:** Alex Lim, Yun Ji Seo, Luran Wang  
**Prepared:** October 31, 2026  
**Purpose:** Reproducible data preparation and validity checks, not an app or a completed term-project submission.

## Status: research and tested preparation tools, not a cleaned empirical dataset

The earlier conversation reported 18 Route 22 arrivals, 23 Route 23 arrivals and six Route 215 departures on October 15, 2026, 16:00–19:00. The original starter ZIP was not mounted in the current analysis session. Attempts to retrieve binary source data also failed. Therefore this kit contains **no newly verified MBTA trip rows, no computed empirical baseline, no selected observed scenarios, and no optimization results**.

Official documentation was reviewed online. Source labels S1–S10 below refer to `sources.csv`; public-source facts are separated from our proposed study rules. The preparation scripts passed 17 synthetic unit/integration tests in this environment. Their Parquet reader has not been exercised on the original event file; the CSV event-audit path has been tested. Downloader tests use mocked responses, not successful live transfers. `test_results.txt` records the actual test run. Synthetic fixtures are generated in temporary folders and are never presented as MBTA observations.

The default numerical assumptions are illustrative, not MBTA operating standards. In particular, a 180-second transfer allowance, 180-second turnaround, 300-second headway tolerance and 7,200-second stranded cost require team review. They must not become unqualified facts in the report.

## 1. Preserve the agreed research question

Scope A chooses small, trip-consistent changes to selected Route 215 departures to minimize mean waiting cost for a fixed cohort of incoming Routes 22/23 trips under scheduled operation.

Scope B chooses ONE set of those changes to minimize the largest scenario-average cost over scheduled, representative-delay and disrupted-delay scenarios. It is not a different timetable for each scenario and not minimization of the longest individual wait.

Use one equally weighted opportunity per eligible incoming trip. This is an opportunity-level measure, not an estimate of actual passenger waiting. Preserve the cohort even when an observed bus arrives after 19:00.

## 2. Run the schedule extraction

Python 3.10 or newer is sufficient for Scope A; no third-party packages are required.

```sh
python prepare_scope_a.py \
  --input MBTA_Ashmont_Project_Starter_2026-10-16.zip \
  --config config.json \
  --out outputs/scheduled_20261015
```

A direct GTFS ZIP or directory of GTFS `.txt` files is also supported. The nested ZIP loader expects exactly one nested GTFS feed. It does not extract arbitrary ZIP paths to disk.

Review the stop inventory and terminal/destination filters. Stop `334` is carried forward from prior notes, not newly independently verified. Incoming trips must end at the configured Ashmont stop and permit ordinary alighting; outgoing Route 215 trips must start there, permit ordinary boarding, and have a headsign matching `Quincy Center`. Conditional pickup/drop-off is flagged, not silently modeled. The script exports all selected-route Ashmont events for inspection.

The date filter applies `calendar.txt` plus `calendar_dates.txt`. All-day Route 215 departures are retained; only departures originally scheduled in `[16:00,19:00)` are adjustable. All active routes are scanned when reconstructing affected vehicle blocks. Relevant neighbors outside the window and on other routes are retained.

The script deliberately leaves results marked `PROVISIONAL_REQUIRES_REVIEW` until the team verifies historical publication applicability, transfer-rule precedence and operating assumptions. A calendar-compatible feed is not automatically the historical feed in force. A `BLOCKED` output means at least one extraction/model-input defect needs resolution. Count differences from prior notes are reported, never silently forced to 41 or six.

### Outputs

| File | Meaning |
|---|---|
| `incoming.csv` | One row per selected incoming-trip opportunity, with source identifiers and seconds |
| `outgoing.csv` | All-day eligible Route 215 departures and an adjustable indicator |
| `ashmont_all_route_events.csv` | Audit view including reverse-direction/start/end records |
| `vehicle_links.csv` | Adjacent affected block-trip pairs, gaps and assumed required gaps |
| `block_trip_endpoints.csv` | Endpoints of every active trip in affected blocks, including other routes |
| `shift_bounds.csv` | Bounds from fixed neighbors; NOT a replacement for coupled block/headway constraints |
| `headway_limits.csv` | Original headways plus explicitly assumed tolerances, including boundary pairs |
| `selected_trip_stop_times.csv` | Complete selected-trip stop sequences to shift consistently |
| `ashmont_stops.csv`, `transfers_for_review.csv`, `pathways_for_review.csv` | Location/transfer evidence; not an automatically chosen walking allowance |
| `baseline_connections.csv` | Earliest eligible scheduled connection, waits and stranded indicator |
| `baseline_transfer_sensitivity.csv` | Baseline evaluated under 2-, 3- and 5-minute allowance assumptions |
| `baseline_metrics.json` | Served-only waits and all-opportunity penalized cost separately |
| `audit.json`, `quality_issues.csv` | Provenance, counts, exclusions, unresolved checks and configuration |

Trip occupation ends use the last scheduled departure or arrival, whichever is later, so scheduled final-stop dwell is not erased. Exported `gap_from_last_arrival_sec` separately allows comparison with earlier five-minute-arrival-gap notes. The turnaround input is additional to this occupation end. That convention must be used consistently in the model.

Different predecessor/successor terminal IDs require a reviewed deadhead allowance. Add entries such as `"stopA->stopB": 120` to `deadhead_seconds_by_stop_pair` only with a documented basis. A common parent station is not proof of zero vehicle repositioning time. Missing block endpoints and unknown deadheads are blockers. Public block starts/ends are not proof of depot or crew feasibility.

Transfer type 3 prohibitions and type 4/5 linked-trip records need manual precedence checks. The kit exports and flags these rather than claiming an authoritative automatic transfer/vehicle-link resolver.

## 3. Historical feed verification and retrieval

Official source URLs, purposes and access status are in `sources.csv`. The archive rules here come from S1; general service-day/calendar semantics come from S4. LAMP's archive uses applicability columns `gtfs_active_date` and `gtfs_end_date`. For the target date, use both inequalities against `20261015` on every table, then apply the GTFS operating calendar. `archive_metadata.sql` is an inspection query for the dated feed metadata; it was not executed against the live binary archive here.

Inspect `feed_info.txt` in the saved ZIP and compare the applicable archive records. If versions differ, compare actual relevant calendar, trip, stop-time and block rows before deciding whether the saved ZIP is usable. Do not replace it with today's live GTFS and call the result October 15 data. Record source URL, UTC retrieval time, feed/version information and SHA-256 for every raw snapshot.

`download_source.py` provides an explicit, size-limited downloader. Example, on a network-connected machine:

```sh
python download_source.py \
  --url https://performancedata.mbta.com/lamp/gtfs_archive/2026/feed_info.parquet \
  --out raw/feed_info_2026.parquet --max-mb 50
```

The full recent bus-events source and annual stop-time tables may be large. Inspect their sizes and available local snapshots before downloading. File names containing `RECENT` do not establish the covered dates: inspect the file's actual service-date range. No claim is made here that the current endpoint still contains October 15 records.

The downloader records success/failure and HTTP/checksum metadata. Header checks are not full Parquet validity checks. A failed download is not an empty dataset.

## 4. Audit observed events without silently repairing them

Optional dependencies are listed in `requirements-events.txt`.

```sh
python -m pip install -r requirements-events.txt
python audit_events.py \
  --events Ashmont_bus_events_2026-10-16.parquet \
  --schedule-dir outputs/scheduled_20261015 \
  --out outputs/events_20261015
```

Extract the named event file from the starter ZIP first. CSV input is also supported. The script processes batches and retains only configured Ashmont route/stop records for the specified service date. It preserves ambiguous vehicle records instead of averaging or arbitrarily keeping the first. It matches on the GTFS stop sequence when available; a unique trip-stop fallback is explicitly marked for review. A LAMP event sequence is not assumed identical to a GTFS sequence.

Outputs are `event_alignment_diagnostics.csv`, `scheduled_event_coverage.csv`, and `event_audit.json`. Coverage includes all exported scheduled Ashmont route events, not just the 41-opportunity cohort. Use `incoming.csv` to identify the evaluation cohort.

The bus-field interpretations here are based on S3; walking and buffer distinctions are based on S2. The four-hour issue is unresolved until actual rows are examined. The auditor compares planned UTC-aware datetimes and planned numeric seconds separately against the matched GTFS departure. It also compares observed numeric fields with canonical timestamp-derived seconds. It never adds/subtracts four hours automatically. Offset-free datetime strings remain unusable until their convention is established.

For UTC timestamp comparison, GTFS service seconds use the documented local-noon-minus-twelve-elapsed-hours anchor, avoiding an implicit fixed UTC offset. Scheduled arrival must be compared with observed arrival; scheduled departure with observed departure. This matters when a stop has scheduled dwell.

The event audit is **not a scenario builder**. Nonmissing timestamps alone do not certify a complete trip, a unique vehicle assignment, or a feasible vehicle chain. The original Ashmont-only extract may lack Quincy terminal and predecessor/successor events needed for Scope B.

## 5. Proposed empirical scenario procedure

Freeze a suitable weekday date range and train/test split before optimizing. Prefer days with the same relevant timetable and a fully matched fixed cohort. A provisional target is at least ten compatible complete weekdays, with five held out; this is a planning target, not a statistical theorem or a guarantee of adequate power.

For the training days, replay the original timetable using each day's joint arrival/departure pattern. Choose the typical day nearest the median day-level baseline waiting cost and a disrupted day near the upper tail using a prespecified rule. Keep complete day vectors so route/vehicle correlations are preserved. A date with uniformly high delays is not necessarily worst for transfers: relative arrival/departure timing matters. Add the scheduled case as the third scenario.

If data are too sparse, label the extension as a limited observed-day case study or synthetic stress test. Do not claim population-level robustness. Report exclusions and compare missingness across ordinary/disrupted days; complete-case filtering may remove the most disrupted days.

Apply any fixed timetable to held-out days without reoptimization. Compare paired differences by day; resample whole days, not individual transfer opportunities, for exploratory uncertainty intervals. Never tune the scenario-selection rule on the held-out results.

## 6. Operating and evaluation safeguards

For each affected block pair, impose `end_p + x_p + required_gap_pq <= start_q + x_q`. Unselected trips have zero shift. The six shifts are not automatically independent: keep headway and block coupling after computing individual bounds. On every selected trip, shift every arrival and departure by the same amount.

For fixed timetables, define passenger readiness as `arrival + allowance`; catch the earliest departure at or after readiness. The allowance incorporates the chosen walking/boarding convention. Post-allowance wait (called `platform_wait_sec` in the code) is `departure - readiness`; total transfer time is `departure - arrival`. If the allowance includes a recommended buffer rather than only physical walking, the first quantity is not a literal measured platform-dwell time. Compare total transfer time as well when changing allowance assumptions. The evaluator computes both. A no-service penalty applies only when no eligible bus remains, not when the optimizer prefers the penalty to a long wait. Report stranded opportunities separately. Do not remove them from the cost denominator.

In Scope B, adding observed lags unchanged after retiming is an explicit local counterfactual assumption. Check vehicle end/start feasibility under every scenario. If delayed operation is simulated with propagation, the same dispatch rule must apply to every candidate and benchmark. Do not let scenario-dependent departure variables create free holding decisions beyond the agreed timetable.

In a minimax formulation, connection variables in a nonbinding scenario may not select the earliest bus unless that behavior is enforced. Evaluate the resulting common timetable independently with an earliest-departure routine; do not blindly report arbitrary solver assignments as passenger behavior.

Do not call a timetable deployable merely because the simplified constraints pass. Crew duties, garage movements, capacity, traffic effects, other passenger groups and terminal bay operations remain outside the baseline model. A small or zero improvement is a valid outcome.

## 7. Benchmarks, checks and ownership

Use the original timetable, a deterministic feasible adjustment heuristic, and Scope A optimum; add Scope B only when validated. The heuristic should use the same feasibility checks and tie-breaking rules. Compare using a single independent evaluator.

Before optimization, check the zero-shift timetable against all chosen constraints. If it fails, investigate the assumption or extracted chain; do not quietly weaken only the benchmark. Small synthetic examples should test missed connections, equality at readiness, window boundaries, penalty logic, all-trip shifts and conflicting block constraints. For a small discrete instance, enumeration can independently check the solver objective.

Following the reporting interfaces in S8, store solver termination/primal status, incumbent objective, bound, gap, runtime and versions. Use parameter reruns rather than treating MILP LP-relaxation dual values as global sensitivity results.

Suggested division: Alex owns dated schedules/baselines; Yun Ji owns operating constraints/model checks; Luran owns event validation/scenario design and independent evaluation. Rotate review so every result has a second reviewer. This is a suggested allocation, not an agreed assignment.

The interim-report date carried forward from the supplied syllabus is November 6, final submission December 7, and presentations December 9/10 by section; confirm course updates. The previous October 23–29 checklist is now a backlog, not a future week.

Use these materials as research/preparation support. The team should understand, review and disclose any AI assistance according to the course policy and author its own submission and conclusions.

## 8. Re-run tests

```sh
python -m unittest discover -s tests -v
```

The 17 tests cover service dates/exceptions, hours above 24, readiness equality, missed buses, true stranding, preventing optional stranding, UTC conversion in summer/winter/DST transition, naive timestamps, nested ZIP handling, cross-route block neighbors, after-window departures, ambiguity preservation, mismatched planned fields, output-overwrite protection and mocked downloader handling. These are targeted software checks, not exhaustive certification.
