-- Inspection query; not executed on the live archive in this analysis.
-- Requires network access, DuckDB and its httpfs extension.
-- This examines publication applicability, NOT weekday operating-calendar eligibility.
INSTALL httpfs;
LOAD httpfs;
SELECT *
FROM read_parquet('https://performancedata.mbta.com/lamp/gtfs_archive/2026/feed_info.parquet')
WHERE gtfs_active_date <= 20261015
  AND gtfs_end_date >= 20261015;

-- Apply the same date predicate to every archived table used.
-- Inspect schemas before materializing: do not assume archived time fields
-- are HH:MM:SS strings rather than numeric seconds.
-- Then select active service_id values using calendar + calendar_dates.
