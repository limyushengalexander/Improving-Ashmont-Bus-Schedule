#!/usr/bin/env python3
"""Audit one date of LAMP events against a dated Scope A extraction.

Parquet support requires pandas+pyarrow. CSV support requires pandas.
No automatic four-hour correction, duplicate averaging, missing=on-time
imputation, scenario selection, or empirical robustness claims are made.
"""
from __future__ import annotations
import argparse
import json
import sys
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo


def gtfs_anchor_utc(service_date: str, tz: str = 'America/New_York') -> datetime:
    """GTFS time origin: local noon minus twelve elapsed hours."""
    d = date.fromisoformat(service_date)
    noon = datetime.combine(d, time(12), tzinfo=ZoneInfo(tz))
    return noon.astimezone(timezone.utc)-timedelta(hours=12)


def canonical_seconds(value, service_date: str, tz: str = 'America/New_York') -> float | None:
    if value is None or str(value) in ('', 'NaT', 'nan', '<NA>'):
        return None
    # CSV datetimes without an offset are ambiguous: do not silently assume UTC.
    dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    if dt.tzinfo is None:
        return None
    return (dt.astimezone(timezone.utc)-gtfs_anchor_utc(service_date,tz)).total_seconds()


def normalized_date(value) -> str:
    s = str(value)
    if len(s)==8 and s.isdigit():
        return date(int(s[:4]),int(s[4:6]),int(s[6:8])).isoformat()
    return date.fromisoformat(s[:10]).isoformat()


def audit(events_path: Path, schedule_dir: Path, output_dir: Path):
    import pandas as pd
    from prepare_scope_a import sha256
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError('Output directory must be absent or empty.')
    output_dir.mkdir(parents=True, exist_ok=True)
    source_audit = json.loads((schedule_dir/'audit.json').read_text())
    cfg = source_audit['config']
    day, tz = cfg['service_date'], cfg.get('timezone','America/New_York')
    schedule = pd.read_csv(schedule_dir/'ashmont_all_route_events.csv',dtype=str,keep_default_na=False)
    schedule = schedule.to_dict('records')
    schedule_index = {}
    for r in schedule:
        key = (r['trip_id'],r['stop_id'],r['stop_sequence'])
        if key in schedule_index:
            raise ValueError(f'Ambiguous schedule key: {key}')
        schedule_index[key] = r
    fallback = {}
    for r in schedule:
        fallback.setdefault((r['trip_id'],r['stop_id']),[]).append(r)
    route_ids = set(cfg['incoming_routes']+[cfg['outgoing_route']])
    focus = set(cfg['ashmont_stop_ids'])
    records, input_rows, errors = [], 0, Counter()
    if events_path.suffix.lower()=='.parquet':
        try:
            import pyarrow.parquet as pq
        except ImportError as exc:
            raise ValueError('Parquet input requires pyarrow; install optional requirements.') from exc
        pf = pq.ParquetFile(events_path)
        batches = (b.to_pandas() for b in pf.iter_batches(batch_size=100000))
    elif events_path.suffix.lower()=='.csv':
        batches = pd.read_csv(events_path,dtype=str,keep_default_na=False,chunksize=100000)
    else:
        raise ValueError('Input must be a CSV or Parquet file, not a ZIP. Extract the event member first.')
    required = {'service_date','trip_id','route_id','stop_id'}
    for frame in batches:
        input_rows += len(frame)
        if not required.issubset(frame.columns):
            raise ValueError(f'Missing required event columns: {sorted(required-set(frame.columns))}')
        frame = frame.loc[frame.route_id.astype(str).isin(route_ids)&frame.stop_id.astype(str).isin(focus)].copy()
        frame = frame.astype(object).where(pd.notna(frame),None)
        for r in frame.to_dict('records'):
            try:
                event_day = normalized_date(r['service_date'])
            except ValueError:
                errors['unparseable_service_date'] += 1
                continue
            if event_day != day:
                continue
            tid,sid = str(r['trip_id']),str(r['stop_id'])
            seq = r.get('gtfs_stop_sequence')
            has_gtfs_seq = seq is not None and str(seq) not in ('','nan','<NA>')
            if has_gtfs_seq:
                try:
                    key = (tid,sid,str(int(float(seq))))
                except ValueError:
                    key = (tid,sid,'INVALID')
                match = schedule_index.get(key)
                match_type = 'gtfs_sequence' if match else 'unmatched_gtfs_sequence'
            else:
                candidates = fallback.get((tid,sid),[])
                match = candidates[0] if len(candidates)==1 else None
                match_type = 'unique_trip_stop_fallback_review' if match else 'unmatched_or_ambiguous_trip_stop'
            out = {k:('' if v is None else str(v)) for k,v in r.items()}
            out['service_date'] = day
            out['schedule_match_method'] = match_type
            out['schedule_route_agrees'] = '' if match is None else int(str(r['route_id'])==match['route_id'])
            out['scheduled_arrival_sec'] = '' if match is None else match['arrival_sec']
            out['scheduled_departure_sec'] = '' if match is None else match['departure_sec']
            out['scheduled_sequence'] = '' if match is None else match['stop_sequence']
            parsed = {}
            for field in ['plan_stop_departure_dt','stop_arrival_dt','stop_departure_dt']:
                try:
                    parsed[field] = canonical_seconds(r.get(field),day,tz)
                except (ValueError, TypeError):
                    parsed[field] = None
                    errors['bad_datetime_'+field] += 1
                if r.get(field) not in (None,'') and parsed[field] is None:
                    errors['unusable_or_naive_'+field] += 1
                out[field+'_canonical_sec'] = '' if parsed[field] is None else parsed[field]
            # Diagnostics only. Planned-field mismatches are never patched here.
            dep0 = float(match['departure_sec']) if match else None
            arr0 = float(match['arrival_sec']) if match else None
            pdt, adt, ddt = (parsed[k] for k in ['plan_stop_departure_dt','stop_arrival_dt','stop_departure_dt'])
            out['planned_datetime_minus_gtfs_sec'] = '' if pdt is None or dep0 is None else pdt-dep0
            try:
                sam = float(r['plan_stop_departure_sam'])
            except (KeyError,ValueError,TypeError):
                sam = None
            out['planned_numeric_minus_gtfs_sec'] = '' if sam is None or dep0 is None else sam-dep0
            out['diagnostic_arrival_delay_sec'] = '' if adt is None or arr0 is None else adt-arr0
            out['diagnostic_departure_delay_sec'] = '' if ddt is None or dep0 is None else ddt-dep0
            for raw_field, canonical in [('stop_arrival_seconds', adt), ('stop_departure_seconds', ddt)]:
                try:
                    raw_seconds = float(r[raw_field])
                except (KeyError, ValueError, TypeError):
                    raw_seconds = None
                out[raw_field+'_minus_canonical_sec'] = '' if raw_seconds is None or canonical is None else raw_seconds-canonical
            out['departure_before_arrival'] = '' if adt is None or ddt is None else int(ddt<adt)
            records.append(out)
    frame = pd.DataFrame(records)
    if records:
        fullkey = ['service_date','route_id','trip_id','stop_sequence','tm_pullout_id','vehicle_label']
        present = [k for k in fullkey if k in frame.columns]
        duplicate_rows = int(frame.duplicated(present,keep=False).sum()) if present else None
        frame['ambiguous_observed_match'] = frame.duplicated(['service_date','trip_id','stop_id','scheduled_sequence'],keep=False).astype(int)
        frame.to_csv(output_dir/'event_alignment_diagnostics.csv',index=False)
        # Availability of every relevant scheduled Ashmont event, including missing observations.
        counts = Counter((r['trip_id'],r['stop_id'],str(r['scheduled_sequence']))
                         for r in records if r['scheduled_sequence']!='')
        coverage = []
        for r in schedule:
            n = counts[(r['trip_id'],r['stop_id'],r['stop_sequence'])]
            coverage.append(dict(r,observed_candidate_count=n,
                                 match_status='missing' if n==0 else 'unique' if n==1 else 'ambiguous'))
        pd.DataFrame(coverage).to_csv(output_dir/'scheduled_event_coverage.csv',index=False)
    else:
        duplicate_rows = 0
        frame.to_csv(output_dir/'event_alignment_diagnostics.csv',index=False)
        coverage = [dict(r, observed_candidate_count=0, match_status='missing') for r in schedule]
        pd.DataFrame(coverage).to_csv(output_dir/'scheduled_event_coverage.csv',index=False)
    def distribution(column):
        return dict(Counter(str(r.get(column,'')) for r in records))
    result = {
        'status':'DIAGNOSTICS_ONLY_NOT_VALIDATED_SCENARIOS', 'service_date':day,
        'event_input_sha256':sha256(events_path),'schedule_gtfs_sha256':source_audit.get('gtfs_sha256'),
        'input_rows_scanned':input_rows,'filtered_ashmont_event_rows':len(records),
        'duplicate_rows_on_available_full_key':duplicate_rows,
        'schedule_match_counts':distribution('schedule_match_method'),
        'planned_datetime_minus_gtfs_distribution_sec':distribution('planned_datetime_minus_gtfs_sec'),
        'planned_numeric_minus_gtfs_distribution_sec':distribution('planned_numeric_minus_gtfs_sec'),
        'arrival_numeric_minus_canonical_distribution_sec':distribution('stop_arrival_seconds_minus_canonical_sec'),
        'departure_numeric_minus_canonical_distribution_sec':distribution('stop_departure_seconds_minus_canonical_sec'),
        'coverage_counts':dict(Counter(r['match_status'] for r in coverage)),
        'parse_warnings':dict(errors),
        'restrictions':['No automatic timezone repair or ambiguity resolution.',
                        'Do not interpret missing telemetry as cancellation or zero delay.',
                        'This checks Ashmont only; Scope B also needs affected terminal/vehicle-chain observations.',
                        'The source schedule still requires historical applicability verification.']}
    (output_dir/'event_audit.json').write_text(json.dumps(result,indent=2))
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--events',type=Path,required=True)
    p.add_argument('--schedule-dir',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:
        result=audit(a.events,a.schedule_dir,a.out)
        print(json.dumps(result,indent=2))
    except (OSError,ValueError,KeyError,ImportError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
