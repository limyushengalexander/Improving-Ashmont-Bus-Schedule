#!/usr/bin/env python3
"""Explicit, size-limited official-source downloader with checksum manifest.
Does not replace historical schedules with the current feed. No network work
is claimed unless this script completes and writes a successful manifest.
"""
import argparse
import hashlib
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ALLOWED_HOSTS = {'performancedata.mbta.com','cdn.mbta.com','raw.githubusercontent.com'}

def download(url, destination, max_mb=250):
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme!='https' or parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError('Only HTTPS URLs on the documented official source hosts are supported.')
    if max_mb<=0:
        raise ValueError('max-mb must be positive.')
    if destination.exists():
        raise ValueError('Destination exists; choose another name to preserve source snapshots.')
    destination.parent.mkdir(parents=True,exist_ok=True)
    temporary=destination.with_name(destination.name+'.partial')
    if temporary.exists():
        raise ValueError('A partial file exists; inspect/remove it before retrying.')
    limit=int(max_mb*1024*1024)
    manifest={'url':url,'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),'status':'failed'}
    try:
        request=urllib.request.Request(url,headers={'User-Agent':'Academic-Ashmont-Data-Audit/1.0'})
        with urllib.request.urlopen(request,timeout=45) as response:
            length=response.headers.get('Content-Length')
            if length and int(length)>limit:
                raise ValueError(f'Source is {length} bytes; exceeds explicit limit {limit}.')
            hasher=hashlib.sha256()
            total=0
            prefix=b''
            with temporary.open('xb') as out:
                while True:
                    chunk=response.read(1024*1024)
                    if not chunk:
                        break
                    total+=len(chunk)
                    if total>limit:
                        raise ValueError('Download exceeded configured size limit.')
                    if not prefix:
                        prefix=chunk[:4]
                    out.write(chunk)
                    hasher.update(chunk)
            if destination.suffix.lower()=='.parquet' and prefix!=b'PAR1':
                raise ValueError('Downloaded body is not a standard Parquet file.')
            if destination.suffix.lower()=='.zip' and prefix[:2]!=b'PK':
                raise ValueError('Downloaded body is not a ZIP file.')
            if length and total != int(length):
                raise ValueError('Incomplete response: bytes received differ from Content-Length.')
            if total==0:
                raise ValueError('Empty response.')
            temporary.replace(destination)
            manifest.update(status='downloaded',bytes=total,sha256=hasher.hexdigest(),
                            final_url=response.geturl(),etag=response.headers.get('ETag'),
                            last_modified=response.headers.get('Last-Modified'))
    except Exception as exc:
        temporary.unlink(missing_ok=True)
        manifest['error']=str(exc)
        raise
    finally:
        destination.with_name(destination.name+'.manifest.json').write_text(json.dumps(manifest,indent=2))
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url',required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--max-mb',type=float,default=250)
    a=p.parse_args()
    try:
        print(json.dumps(download(a.url,a.out,a.max_mb),indent=2))
    except (OSError,ValueError,urllib.error.URLError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
