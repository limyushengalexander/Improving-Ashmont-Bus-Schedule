"""Synthetic edge-case tests only; not empirical MBTA observations."""
import csv
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_scope_a import gtfs_seconds,active_services,match_waits,prepare,Feed
from audit_events import canonical_seconds,audit
from download_source import download

ROOT=Path(__file__).resolve().parents[1]

def csv_text(rows):
    buf=io.StringIO()
    fields=list(dict.fromkeys(k for r in rows for k in r))
    writer=csv.DictWriter(buf,fieldnames=fields)
    writer.writeheader();writer.writerows(rows)
    return buf.getvalue()

def fixture_zip(path):
    calendar=[{'service_id':'WK','monday':'1','tuesday':'1','wednesday':'1','thursday':'1','friday':'1',
               'saturday':'0','sunday':'0','start_date':'20261001','end_date':'20261231'}]
    trip_specs=[
        ('I22','22','A','334','16:00:00','16:15:00','Ashmont',''),
        ('I23','23','A','334','18:30:00','18:59:00','Ashmont',''),
        ('REVERSE22','22','334','A','16:30:00','16:50:00','Other terminus',''),
        ('P','999','A','334','15:45:00','16:15:00','Ashmont','B1'),
        ('O','215','334','Q','16:20:00','16:50:00','Quincy Center','B1'),
        ('S','999','Q','A','16:55:00','17:25:00','Other terminus','B1'),
        ('TAIL','215','334','Q','19:10:00','19:40:00','Quincy Center','B2')]
    trips=[];times=[]
    for tid,route,first,last,start,end,head,block in trip_specs:
        trips.append({'trip_id':tid,'route_id':route,'service_id':'WK','block_id':block,'trip_headsign':head,'direction_id':'0'})
        times.extend([{'trip_id':tid,'stop_id':first,'stop_sequence':'1','arrival_time':start,'departure_time':start,'pickup_type':'0','drop_off_type':'1'},
                      {'trip_id':tid,'stop_id':last,'stop_sequence':'2','arrival_time':end,'departure_time':end,'pickup_type':'1','drop_off_type':'0'}])
    stops=[{'stop_id':sid,'stop_name':name,'parent_station':''} for sid,name in [('334','Ashmont'),('A','Another terminal'),('Q','Quincy Center')]]
    with zipfile.ZipFile(path,'w') as z:
        for name,rows in [('calendar',calendar),('trips',trips),('stop_times',times),('stops',stops),
                          ('feed_info',[{'feed_start_date':'20261001','feed_end_date':'20261231','feed_version':'SYNTHETIC TEST ONLY'}])]:
            z.writestr(name+'.txt',csv_text(rows))


def configuration():
    cfg=json.loads((ROOT/'config.json').read_text())
    cfg['expected_counts_from_prior_notes']={}
    return cfg

class PipelineTests(unittest.TestCase):
    def test_extended_service_day(self):
        self.assertEqual(gtfs_seconds('25:01:02'),90062)
    def test_reject_invalid_clock(self):
        with self.assertRaises(ValueError):gtfs_seconds('16:60:00')
    def test_calendar_overrides(self):
        cal=[{'service_id':'WK','thursday':'1','start_date':'20260101','end_date':'20261231'}]
        ex=[{'service_id':'WK','date':'20261015','exception_type':'2'},
            {'service_id':'SPECIAL','date':'20261015','exception_type':'1'}]
        self.assertEqual(active_services(cal,ex,'2026-10-15'),{'SPECIAL'})
    def test_exact_ready_catches(self):
        incoming=[{'opportunity_id':'i','route_id':'22','trip_id':'i','arrival_sec':100}]
        outgoing=[{'trip_id':'j','departure_sec':280}]
        rows,stats=match_waits(incoming,outgoing,180,7200)
        self.assertEqual(rows[0]['platform_wait_sec'],0)
        self.assertEqual(stats['stranded'],0)
    def test_missed_dep_uses_next(self):
        incoming=[{'opportunity_id':'i','route_id':'22','trip_id':'i','arrival_sec':101}]
        outgoing=[{'trip_id':'j','departure_sec':280},{'trip_id':'k','departure_sec':400}]
        rows,_=match_waits(incoming,outgoing,180,7200)
        self.assertEqual(rows[0]['outgoing_trip_id'],'k')
        self.assertEqual(rows[0]['platform_wait_sec'],119)
    def test_penalty_cannot_replace_available_bus(self):
        incoming=[{'opportunity_id':'i','route_id':'22','trip_id':'i','arrival_sec':1}]
        rows,_=match_waits(incoming,[{'trip_id':'j','departure_sec':1000}],0,5)
        self.assertEqual(rows[0]['stranded'],0)
        self.assertEqual(rows[0]['waiting_cost_sec'],999)
    def test_true_no_remaining_service(self):
        incoming=[{'opportunity_id':'i','route_id':'22','trip_id':'i','arrival_sec':101}]
        rows,stats=match_waits(incoming,[{'trip_id':'j','departure_sec':100}],0,7200)
        self.assertEqual(rows[0]['stranded'],1)
        self.assertEqual(stats['mean_waiting_cost_sec_all'],7200)
        self.assertIsNone(stats['max_platform_wait_sec_served'])
    def test_utc_october(self):
        self.assertEqual(canonical_seconds('2026-10-15T20:20:00Z','2026-10-15'),16*3600+20*60)
    def test_utc_winter(self):
        self.assertEqual(canonical_seconds('2026-12-15T21:20:00Z','2026-12-15'),16*3600+20*60)
    def test_dst_transition_noon_origin(self):
        self.assertEqual(canonical_seconds('2026-11-01T21:20:00Z','2026-11-01'),16*3600+20*60)
    def test_naive_time_is_not_silently_fixed(self):
        self.assertIsNone(canonical_seconds('2026-10-15T16:20:00','2026-10-15'))
    def test_realistic_synthetic_extract(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);fixture_zip(p/'gtfs.zip')
            result=prepare(p/'gtfs.zip',p/'out',configuration())
            self.assertEqual(result['incoming_counts'],{'22':1,'23':1})
            self.assertEqual(result['adjustable_outgoing_count'],1)
            self.assertEqual(result['post_window_outgoing_count'],1)
            with (p/'out'/'shift_bounds.csv').open() as f:bounds=list(csv.DictReader(f))
            self.assertEqual(int(bounds[0]['lower_shift_sec']),-120)
            self.assertEqual(int(bounds[0]['upper_shift_sec']),120)
            with (p/'out'/'vehicle_links.csv').open() as f:links=list(csv.DictReader(f))
            self.assertEqual(len(links),2)
            self.assertEqual(links[0]['predecessor_route_id'],'999')
            with (p/'out'/'baseline_connections.csv').open() as f:waits=list(csv.DictReader(f))
            self.assertEqual(waits[1]['outgoing_trip_id'],'TAIL')
            self.assertEqual(int(waits[1]['platform_wait_sec']),480)
            self.assertEqual(result['status'],'PROVISIONAL_REQUIRES_REVIEW')
    def test_nested_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);fixture_zip(p/'gtfs.zip')
            with zipfile.ZipFile(p/'starter.zip','w') as z:
                z.write(p/'gtfs.zip','MBTA_GTFS_TEST.zip')
                z.writestr('README.md','Synthetic starter fixture')
            feed=Feed(p/'starter.zip')
            self.assertEqual(feed.nested_name,'MBTA_GTFS_TEST.zip')
            self.assertEqual(len(list(feed.rows('trips.txt'))),7)
            feed.close()
    def test_events_preserve_ambiguity_and_timezone_mismatch(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);fixture_zip(p/'gtfs.zip');prepare(p/'gtfs.zip',p/'out',configuration())
            records=[]
            for label in ['VEH1','VEH2']:
                records.append({'service_date':'2026-10-15','trip_id':'O','route_id':'215','stop_id':'334',
                                'gtfs_stop_sequence':'1','stop_sequence':'10', 'tm_pullout_id':label,'vehicle_label':label,
                                'plan_stop_departure_sam':'58800','plan_stop_departure_dt':'2026-10-15T16:20:00Z',
                                'stop_arrival_dt':'2026-10-15T20:19:00Z','stop_departure_dt':'2026-10-15T20:22:00Z'})
            (p/'events.csv').write_text(csv_text(records))
            result=audit(p/'events.csv',p/'out',p/'eventout')
            self.assertEqual(result['filtered_ashmont_event_rows'],2)
            self.assertEqual(result['planned_datetime_minus_gtfs_distribution_sec'],{'-14400.0':2})
            self.assertEqual(result['planned_numeric_minus_gtfs_distribution_sec'],{'0.0':2})
            self.assertEqual(result['coverage_counts']['ambiguous'],1)
            self.assertEqual(result['duplicate_rows_on_available_full_key'],0)
    def test_downloader_validates_magic_and_manifest(self):
        class Response(io.BytesIO):
            headers={'Content-Length':'8','ETag':'synthetic'}
            def geturl(self):return 'https://performancedata.mbta.com/test.parquet'
        with tempfile.TemporaryDirectory() as temp:
            dest=Path(temp)/'test.parquet'
            with patch('urllib.request.urlopen',return_value=Response(b'PAR1TEST')):
                result=download('https://performancedata.mbta.com/test.parquet',dest,1)
            self.assertEqual(result['status'],'downloaded')
            self.assertEqual(result['bytes'],8)
            self.assertTrue(dest.with_name(dest.name+'.manifest.json').exists())
    def test_downloader_rejects_html_instead_of_parquet(self):
        class Response(io.BytesIO):
            headers={'Content-Length':'6'}
        with tempfile.TemporaryDirectory() as temp:
            dest=Path(temp)/'test.parquet'
            with patch('urllib.request.urlopen',return_value=Response(b'<html>')):
                with self.assertRaises(ValueError):
                    download('https://performancedata.mbta.com/test.parquet',dest,1)
            self.assertFalse(dest.exists())
            m=json.loads(dest.with_name(dest.name+'.manifest.json').read_text())
            self.assertEqual(m['status'],'failed')
    def test_no_overwrite_outputs(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);fixture_zip(p/'gtfs.zip');prepare(p/'gtfs.zip',p/'out',configuration())
            with self.assertRaises(ValueError):prepare(p/'gtfs.zip',p/'out',configuration())

if __name__=='__main__':unittest.main(verbosity=2)
