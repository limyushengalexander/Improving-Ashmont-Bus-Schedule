# Historical GTFS reconciliation — Ashmont 6.C57 project

**Checked on:** November 6, 2026  
**Target service date:** Thursday, October 15, 2026; incoming Routes 22/23 arrival window [16:00,19:00), outbound Route 215 to Quincy Center  
**Status:** **RESOLVED FOR THE SCOPE A STUDY DATA**, with MBTA operational-assumption limitations retained.

## Inputs and provenance

| Source | Feed version | Advertised feed coverage | SHA-256 of GTFS ZIP |
|---|---|---|---|
| Original starter's nested `MBTA_GTFS_2026-10-16.zip` | Fall 2026, `2026-10-14T18:47:38+00:00`, version D | October 7–December 12, 2026 | `21578a40f6cb1de9c61ab1c5dde58f1f17c6ed7812953f2fc9baca62a1ccd931` |
| Newly provided official historical archive `20261014.zip` | Fall 2026, `2026-10-21T20:52:18+00:00`, version D | October 14–19, 2026 | `1b5cf25363f7385de8c22c22fe6a336d91dd68616494526ca14994e3b86dd004` |

Both archives passed `ZipFile.testzip()`. The new archive's metadata matches the version listed in the MBTA historical archive entry identified earlier. **This is a retrospectively corrected archive:** its publication timestamp postdates the study service date; it is not evidence that this feed was published or operated on October 15. Its correction is appropriate as a historical-comparison cross-check.

Official archive index: https://cdn.mbta.com/archive/archived_feeds.txt

## Method

1. Ran the original `prepare_scope_a.py` extraction against the new archive, with the finalized `adopted_scope_a_config.json`. The operating calendar, stop terminal positions, vehicle blocks, and all service-day times were parsed afresh.
2. Compared the newly extracted tables against the **independently rerun original starter** in `mbta_fresh_recheck/rebuilt_scope_a_adopted/`.
3. Compared all 32 raw GTFS table files by uncompressed SHA-256 digest.
4. Independently recomputed the next eligible departure for each incoming arrival and checked every row against the exported baseline, then recomputed the six vehicle shift intervals from the predecessor/successor times and assumed minimum gaps.

## Results

**16 of 17 compared Scope A CSV/JSON study outputs are identical byte-for-byte.** The sole different study output is `feed_info.csv`, as expected. `audit.json` also differs because it records source hashes, input names, and generation times, and is intentionally excluded from content-identity scoring. `config_used.json` is identical. Matched operational files include all 41 incoming opportunities, all 37 onward departures, all baseline connection rows and statistics, all 12 relevant vehicle links, block endpoints, six trip trajectories, shift bounds, headway limits, and relevant station transfer/pathway extracts.

| Study calculation | Archived GTFS | Earlier starter study |
|---|---:|---:|
| Route 22 terminal arrivals 16:00–19:00 | 18 | 18 |
| Route 23 terminal arrivals 16:00–19:00 | 23 | 23 |
| Editable Route 215 departures | 6 | 6 |
| All-day onward departures | 37 | 37 |
| Onward departures at or after 19:00 | 10 | 10 |
| Opportunities catching an after-19:00 departure | 2 | 2 |
| Mean post-allowance waiting (3-minute assumption) | 13.5122 minutes | 13.5122 minutes |
| Maximum post-allowance waiting | 30.0 minutes | 30.0 minutes |
| Stranded opportunities | 0 | 0 |

Shift intervals under the **assumed** minimum three-minute scheduled turnaround, additional two minutes for a different Quincy berth, ±5-minute trip movement, and ±5-minute headway deviation remain unchanged:

| Original Route 215 departure | Minimum shift | Maximum shift |
|---|---:|---:|
| 16:20 | −2 min | +1 min |
| 16:50 | −2 min | +5 min |
| 17:20 | −2 min | +4 min |
| 17:50 | −2 min | +5 min |
| 18:20 | −2 min | +5 min |
| 18:52 | −4 min | +3 min |

These are **individual vehicle-based bounds**; the final solver must also respect coupled service-spacing and full-vehicle constraints. Zero shifts remain feasible under the assumed model.

**The complete GTFS feeds are NOT identical.** Of 32 raw GTFS tables, 19 have identical uncompressed content and 13 differ, including `trips.txt`, `stop_times.txt`, `calendar.txt`, and `feed_info.txt`. The raw changes are outside the extracted service-date cohort or otherwise do not affect the extracted study records. Do not claim the entire MBTA system schedule was unchanged.

## Interpretation and remaining limits

- **Scope A historical feed reconciliation is complete for the defined Oct 15 study cohort and relevant vehicle constraints.** The initial baseline and bounds do not require updating, and the historically corrected archive can now be cited as the principal timetable source. Preserve the original feed as an audit snapshot.
- **Scope B data reconciliation is not complete.** The new archive covers Oct 14–19; Oct 13 needs its appropriate date-specific feed, and actual event timestamps/vehicle endpoint observations still require validation. Being able to match scheduled trips does not establish actual operational delays.
- **MBTA operational certification remains outside this analysis.** Three-minute passenger transfer/vehicle turnaround, two-minute berth movement, and adjustment/headway limits are project assumptions. Crew scheduling, operational rules and actual berth travel are not independently approved by MBTA.
- The source preparation script retains a generic `archive_applicability_unverified` review flag because it does not itself query the official archived feed index; this report resolves that review specifically for the Oct 15 defined Scope A comparison, not generically for any historical date.

## Files and how to reproduce

- `archive_scope_a/` — complete Scope A data extraction from the user-supplied official historical ZIP.
- `scope_a_comparison.csv` — exact hashes and match flags for 17 study outputs.
- `gtfs_file_hash_comparison.csv` — 32 raw GTFS table hashes; shows the differences outside this study.
- `archived_shift_bounds_review.csv` — shift bounds recomputed from archived vehicle links.
- `reconciliation_summary.json` — machine-readable summary with source hashes.
- `prepare_scope_a.py` — same extraction code used in earlier research kit.
- `verify_archive.py` — independent table comparison and baseline/shift validation.

From the directory containing the ZIPs, using Python 3.10+:

```bash
python prepare_scope_a.py --input 20261014.zip \
  --config adopted_scope_a_config.json \
  --out archive_scope_a
python verify_archive.py
```

Scripts assume the named reference files are placed in the paths identified in the package. No Julia optimization was performed in this reconciliation step.
