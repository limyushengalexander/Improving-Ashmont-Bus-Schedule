from pathlib import Path
from zipfile import ZipFile
import io,hashlib,csv,json,statistics,bisect
ROOT=Path(__file__).resolve().parent
old=Path('/mnt/data/mbta_fresh_recheck/rebuilt_scope_a_adopted')
new=ROOT/'archive_scope_a'
archives=[Path('/mnt/data/MBTA_Ashmont_Project_Starter_2026-10-16 (1).zip'),Path('/mnt/data/20261014.zip')]
sha=lambda b:hashlib.sha256(b).hexdigest()
with ZipFile(archives[0]) as z:
 data=z.read('MBTA_GTFS_2026-10-16.zip')
with ZipFile(io.BytesIO(data)) as z0, ZipFile(archives[1]) as z1:
 ns=sorted(set(z0.namelist()) | set(z1.namelist()))
 feed_compare=[]
 for n in ns:
  b0=z0.read(n) if n in z0.namelist() else None
  b1=z1.read(n) if n in z1.namelist() else None
  feed_compare.append({'gtfs_file':n,'starter_present':b0 is not None,'archive_present':b1 is not None,'content_identical': b0==b1,'starter_sha256':sha(b0) if b0 is not None else '', 'archive_sha256':sha(b1) if b1 is not None else ''})
with (ROOT/'gtfs_file_hash_comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(feed_compare[0]));w.writeheader();w.writerows(feed_compare)
compare=[]
for p in sorted(new.iterdir()):
 if p.suffix != '.csv' and p.name not in ('baseline_metrics.json','config_used.json'):continue
 if not (old/p.name).exists():continue
 compare.append({'file':p.name,'identical':p.read_bytes()==(old/p.name).read_bytes(),'source':'20261014.zip vs starter ZIP adopted-config reconstruction','data_sha256':sha(p.read_bytes()),'previous_sha256':sha((old/p.name).read_bytes())})
with (ROOT/'scope_a_comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(compare[0]));w.writeheader();w.writerows(compare)
# Independently reconstruct waiting from raw CSV, without original match_waits implementation.
def rows(file):
 with file.open() as f:return list(csv.DictReader(f))
inc=rows(new/'incoming.csv');departures=rows(new/'outgoing.csv');original=rows(new/'baseline_connections.csv')
assert len(inc)==41 and len(departures)==37 and len(original)==41
assert sum(int(d['is_adjustable']) for d in departures)==6
T=sorted((int(d['departure_sec']),d['trip_id']) for d in departures)
for arr,b in zip(inc,original):
 ready=int(arr['arrival_sec'])+180
 valid=[(t,trip_id) for t,trip_id in T if t>=ready]
 assert valid, f'No eligible departure for {arr["trip_id"]}'
 time,trip_id=valid[0]
 assert time==int(b['departure_sec']) and trip_id==b['outgoing_trip_id'] and time-ready==int(b['platform_wait_sec'])
waits=[int(b['platform_wait_sec']) for b in original]
metrics=json.loads((new/'baseline_metrics.json').read_text())
assert round(sum(waits)/41,12)==round(metrics['mean_platform_wait_sec_served'],12)
assert metrics['stranded']==0 and max(waits)==1800
assert sum(int(b['departure_sec'])>=68400 for b in original)==2
# Confirm each selected departure's shift bounds equal closure summary using the actual trip IDs, times and berth links.
links=rows(new/'vehicle_links.csv');bounds={r['trip_id']:r for r in rows(new/'shift_bounds.csv')}
selected=[r for r in departures if int(r['is_adjustable'])==1]
summary=[]
for row in selected:
 tid=row['trip_id'];prev=[p for p in links if p['successor_trip_id']==tid];nxt=[p for p in links if p['predecessor_trip_id']==tid]
 assert len(prev)==1 and len(nxt)==1
 p,q=prev[0],nxt[0]
 assert int(p['successor_adjustable'])==1 and int(q['predecessor_adjustable'])==1
 before=int(p['scheduled_gap_sec']);after=int(q['scheduled_gap_sec'])
 required_before=int(p['minimum_gap_sec']);required_after=int(q['minimum_gap_sec'])
 lo=max(-300,required_before-before);hi=min(300,after-required_after)
 assert lo==int(bounds[tid]['lower_shift_sec']) and hi==int(bounds[tid]['upper_shift_sec'])
 assert lo<=0<=hi, f'Baseline violates chosen operational assumptions: {tid}'
 summary.append({'trip_id':tid,'departure_time':row['departure_time'],'preceding_gap_min':before/60,'following_gap_min':after/60,'following_route':q['successor_route_id'],'required_before_min':required_before/60,'required_after_min':required_after/60,'minimum_shift_min':lo/60,'maximum_shift_min':hi/60,'zero_shift_feasible':True})
assert len(summary)==6
with (ROOT/'archived_shift_bounds_review.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
res={'feed_versions':{'starter':'Fall 2026, 2026-10-14T18:47:38+00:00, version D','archive':'Fall 2026, 2026-10-21T20:52:18+00:00, version D'},'archive_file_sha256':sha(archives[1].read_bytes()),'starter_gtfs_nested_sha256':sha(data),'gtfs_tables_compared':len(feed_compare),'gtfs_tables_identical':sum(r['content_identical'] for r in feed_compare),'gtfs_tables_different':[r['gtfs_file'] for r in feed_compare if not r['content_identical']],'study_files_compared':len(compare),'study_files_identical':sum(r['identical'] for r in compare),'study_files_different':[r['file'] for r in compare if not r['identical']],'incoming_count_by_route':{r:sum(v['route_id']==r for v in inc) for r in ['22','23']},'outgoing_full_day':len(departures),'adjustable_departures':sum(int(d['is_adjustable']) for d in departures),'after_1900_onward_departures':sum(int(d['departure_sec'])>=68400 for d in departures),'baseline_avg_wait_min':sum(waits)/41/60,'baseline_max_wait_min':max(waits)/60,'baseline_stranded':int(metrics['stranded']),'late_window_connections':sum(int(b['departure_sec'])>=68400 for b in original),'source_zip_checksum_passed':True,'operating_rule_note':'Shift bounds derived under agreed assumed turnaround 180s and berth movement 120s; not MBTA certified.'}
(ROOT/'reconciliation_summary.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
