# 6.C57 MBTA Ashmont — October 23–29 data-preparation milestone

**Team:** Alex Lim, Yun Ji Seo, Luran Wang  
**Study:** October 15, 2026, scheduled arrivals 16:00–19:00, Routes 22 and 23 transferring to Route 215 toward Quincy Center.  
**Decision:** Adopt the explicit *modeling assumptions* below for Scope A; reuse passenger connection rules in Scope B.  
**Status:** 8/8 checklist items complete **for a documented, provisional Scope A data/model specification**. This is not MBTA certification and not a statement that historical timetable version reconciliation is complete.

## A. Passenger-transfer rules — adopted

- A fixed **3-minute allowance** (walking, boarding, and any internal buffer combined). This is **assumed**, not a verified MBTA bus-to-bus minimum for stop 334. Compare **2 and 5 minutes**.
- Arrival readiness: `ready_i = scheduled_arrival_i + 3 min`; a bus that departs exactly at readiness is catchable.
- Passengers catch **the earliest eligible Route 215 departure** at or after readiness; if they miss the first bus they wait for the next eligible bus, without artificial 19:00 truncation. Later service is retained.
- Post-allowance waiting `W_i = onward_departure_i − ready_i`. Report total arrival-to-departure transfer time separately as `T_i = W_i + allowance` when served.
- If no eligible onward bus remains within the full modeled onward schedule, assign a **60-minute cost** for the stranded opportunity, report the stranded count separately, and keep the same original population in the average. A stranded cost may not be chosen instead of a long but available connection.
- Equal weights of one per incoming trip opportunity; these **are not observed passenger counts**.

**Simple boundary checks:** A hypothetical 16:18 arrival is ready at 16:21, misses the 16:20 departure, and takes 16:50: post-allowance wait is 29 minutes. A hypothetical 18:53 arrival is ready at 18:56 and can take 19:20: wait is 24 minutes. These are rule checks, not additional observed MBTA arrivals.

## B. Scheduled vehicle-operating rules — adopted for initial model

- Keep the same routes and trips, and keep incoming Routes 22/23 schedules fixed.
- Adjust **the entire selected Route 215 trip** consistently, with integer-minute shifts in `[-5,+5]`. A future finer grid is optional. Sensitivity: `[-2,+2]`.
- Require **at least 3 minutes between an incoming vehicle trip's finish at Ashmont and its next Route 215 start**, a declared *scheduled planning recovery assumption*. Sensitivity: 2 and 5 minutes.
- After a selected Route 215 trip finishes at Quincy, require at least 3 minutes plus **2 additional minutes** if its next trip begins at a different berth, for a total of **5 minutes**. For same-berth successors use 3 minutes. Reposition sensitivity: 0 and 3 additional minutes.
- Retain all predecessor and successor trips in a vehicle block even when the next route is not 215. No extra trips, no trip-shortening, and no imaginary vehicle exchanges.
- For each successive Route 215 departure, permit at most **±5 minutes of deviation in its original headway**, including fixed boundary departures. For the six adjustable departures this is `|x_(j+1) − x_j| ≤ 5`, with the predecessor and successor shifts taken as zero.

These are **model constraints**, not verified minimum MBTA layover or terminal movement rules. Some actual observed gaps in the uploaded earlier event extract were under 3 minutes, so a 3-minute scheduled planning reserve must not be asserted as a hard observed operating minimum in Scope B.

## C. Vehicle-based shift bounds (minutes)

| Original departure | Preceding gap | Following gap | Next route | Additional berth move? | Shift lower | Shift upper |
|---|---:|---:|---|---|---:|---:|
| 16:20 | 5 | 6 | 220 | Yes | -2 | +1 |
| 16:50 | 5 | 18 | 225 | Yes | -2 | +5 |
| 17:20 | 5 | 9 | 216 | Yes | -2 | +4 |
| 17:50 | 5 | 16 | 225 | Yes | -2 | +5 |
| 18:20 | 5 | 8 | 215 | No | -2 | +5 |
| 18:52 | 7 | 6 | 215 | No | -4 | +3 |

Formulas for each selected trip `j`, with predecessor fixed and successor fixed:

- `shift_min_j = max(-5, 3 - gap_before_j)`.
- `shift_max_j = min(+5, gap_after_j - 3 - (2 if different_berth else 0))`.
- `gap_before_j + shift_j >= 3` and `gap_after_j - shift_j >= 3 + berth_movement_j`.

The script independently enumerates the **six integer-minute shift variables under the adopted vehicle and headway rules**. The unchanged timetable `(0,0,0,0,0,0)` passes all those checks. There are **71,673 feasible joint six-shift combinations** in this *summary-level modeled problem*, including nonzero alternatives. Every value in each stated individual bound occurs in some joint feasible combination, but not all combinations of bound values are allowed.

**Important sensitivity warning:** A **5-minute turnaround + 2-minute additional berth move** makes the original 16:20 trip's 6-minute following gap fail the assumed 7-minute requirement. That case must be labeled **baseline infeasible** (or treated as a distinct, explicitly modified operating design), not compared casually as if the unchanged timetable obeyed the same rules. The 3-minute turnaround + 3-minute berth-move case leaves the baseline feasible.

## D. Evidence and remaining limitations

- The six gap values, successor route labels, berth-change indicators, counts (41 incoming, 6 adjustable, 10 late), and baseline metrics are **from earlier completed extraction and reporting in this conversation**. The underlying ZIP **was not mounted in the current runtime**, so the present script validates their logical implications but does not independently re-read the raw records.
- Baseline previously calculated from supplied snapshot under a 3-minute allowance: **13.51-minute mean post-allowance wait, 30-minute maximum, 0 stranded**. These are not optimized results.
- The corrected historical GTFS archive version still requires reconciliation against the starter snapshot. This is an archival provenance issue, distinct from documenting a workable model.
- Actual Quincy berth movement durations, driver/crew requirements, garage movements, passenger loads, and operating approvals have not been verified. Report conclusions as conditional on model assumptions.
- **Scope B remains incomplete**: resolve raw timestamp conventions, validate historical day-specific timetables, choose scenarios by a declared rule, and check delayed vehicle terminal availability at Quincy. Do not reuse the scheduled planning buffer as an unquestioned physical minimum.

## E. Checklist sign-off interpretation

The eight October 23–29 tasks can be marked **complete for Scope A preparation** under the above *assumption-based* definition. The two formerly open items are now documented and have passed a nominal schedule consistency test. This does **not** establish that the full GTFS historical archive has been reconciled or that all real-world vehicle constraints have been certified.

### Reproduction

```bash
python validate_assumptions.py
```

Outputs: `shift_bounds_checked.csv`, `model_assumptions_and_checks.json`, `turnaround_sensitivity_feasibility.json`.

### Sources

- MBTA GTFS documentation: https://github.com/mbta/gtfs-documentation/blob/master/reference/gtfs.md
- General GTFS reference: https://gtfs.org/documentation/schedule/reference/
- Working data: earlier uploaded `MBTA_Ashmont_Project_Starter_2026-10-16 (1).zip` and previous extracted timetable/vehicle summaries (not mounted for a fresh raw-data audit in this session).
