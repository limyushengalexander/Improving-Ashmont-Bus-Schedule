#!/usr/bin/env python3
"""Validate the agreed 6-trip modeled feasibility assumptions.

IMPORTANT: These inputs are transcribed from the earlier conversation's reported
GTFS extraction. The original source ZIP is NOT mounted in this runtime, so this
is a consistency check on reported gaps, not independent raw-data verification.

All shift decisions are restricted to integer minutes for the initial model.
"""
from itertools import product
from pathlib import Path
import csv, json

OUT = Path(__file__).resolve().parent
TRIPS = [
    # departure HH:MM, before gap, after gap, berth changes at Quincy
    ("16:20", 5, 6, True,  "220"),
    ("16:50", 5,18, True,  "225"),
    ("17:20", 5, 9, True,  "216"),
    ("17:50", 5,16, True,  "225"),
    ("18:20", 5, 8, False, "215"),
    ("18:52", 7, 6, False, "215"),
]
POLICY = {
    "transfer_allowance_min":3,
    "transfer_allowance_sensitivity_min":[2,5],
    "onward_boarding_rule":"earliest_eligible_departure_at_or_after_arrival_plus_transfer_allowance",
    "boarding_at_exact_ready_time_is_allowed":True,
    "missed_connection_rule":"wait_for_next_eligible_departure_including_post_19_00_service",
    "stranded_rule":"apply_penalty_only_if_no_eligible_onward_service_and_report_count_separately",
    "stranded_penalty_min":60,
    "outgoing_shift_abs_max_min":5,
    "outgoing_shift_sensitivity_abs_max_min":[2],
    "scheduled_min_turnaround_min":3,
    "scheduled_turnaround_sensitivity_min":[2,5],
    "extra_quincy_berth_movement_min":2,
    "quincy_berth_movement_sensitivity_min":[0,3],
    "same_berth_movement_min":0,
    "headway_deviation_max_min":5,
    "preserve_trip_counts_and_running_times":True,
    "keep_routes_22_and_23_schedule_fixed":True,
    "time_unit":"integer_minutes_for_shifts",
    "scenario_B_note":"These scheduled planning buffers cannot automatically be imposed as physical minima on historical observed delays.",
    "source_status":"reported_GTFS_derived_summaries_from_prior_turns_NOT_reverified_from_raw_zip_in_current_runtime",
}

def bounds_for(gap_before, gap_after, diff_berth, turn=3, reposition=2, shiftlimit=5):
    lower = max(-shiftlimit, turn-gap_before)
    required_after = turn + (reposition if diff_berth else 0)
    upper = min(shiftlimit, gap_after-required_after)
    return lower, upper

def admissible(shifts, turn=3, reposition=2, headway_tol=5):
    if len(shifts) != len(TRIPS): return False
    for x, (_, before, after, changed, _) in zip(shifts,TRIPS):
        if not -5 <= x <= 5: return False
        if before+x < turn: return False
        if after-x < turn+(reposition if changed else 0): return False
    padded=(0,)+tuple(shifts)+(0,)
    return all(abs(b-a)<=headway_tol for a,b in zip(padded,padded[1:]))


def main():
    rows=[]
    for t,before,after,changed,next_route in TRIPS:
        lower, upper=bounds_for(before,after,changed)
        rows.append({
            "departure":t,
            "scheduled_gap_before_min":before,
            "scheduled_gap_after_min":after,
            "next_route":next_route,
            "different_quincy_berth":str(changed).lower(),
            "required_gap_before_min":3,
            "required_gap_after_min":3+(2 if changed else 0),
            "earliest_shift_min":lower,
            "latest_shift_min":upper,
            "earliest_departure":clockshift(t,lower),
            "latest_departure":clockshift(t,upper),
            "zero_shift_passes":str(lower<=0<=upper).lower(),
        })
    assert [r['earliest_shift_min'] for r in rows]==[-2,-2,-2,-2,-2,-4]
    assert [r['latest_shift_min'] for r in rows]==[1,5,4,5,5,3]
    assert admissible((0,)*6), "The original timetable fails under the agreed rules"
    domains=[range(r['earliest_shift_min'],r['latest_shift_min']+1) for r in rows]
    count=0
    attainable=[set() for _ in TRIPS]
    first_nonzero=None
    for shifts in product(*domains):
        if admissible(shifts):
            count+=1
            if first_nonzero is None and any(shifts):first_nonzero=shifts
            for j,x in enumerate(shifts):attainable[j].add(x)
    assert count>1, "Model assumptions leave only baseline schedule feasible"
    assert all(set(d)==actual for d,actual in zip(domains,attainable)), "Some stated individual shifts are not jointly attainable"
    # A sensitivity is not a valid like-for-like scenario if it invalidates x=0.
    scenario_checks=[]
    for turn in (2,3,5):
        for reposition in (0,2,3):
            valid=admissible((0,)*6,turn=turn,reposition=reposition)
            violating=[t for (t,before,after,changed,_) in TRIPS
                       if before<turn or after<turn+(reposition if changed else 0)]
            scenario_checks.append({"min_turnaround_min":turn,"extra_berth_movement_min":reposition,
                                    "baseline_feasible":valid,"violating_trips":violating})
    (OUT/"turnaround_sensitivity_feasibility.json").write_text(json.dumps(scenario_checks,indent=2)+"\n")
    assert not admissible((0,)*6,turn=5,reposition=2), "5+2 is not compatible with 16:20 baseline"
    assert admissible((0,)*6,turn=3,reposition=3)
    with (OUT/"shift_bounds_checked.csv").open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    detail={
        "study":"Ashmont Route 22/23 to 215 (Oct 15, 2026 scheduled snapshot)",
        "policy":POLICY,
        "trip_rows":rows,
        "check_baseline_zero_shift":"PASS",
        "check_assumed_predecessor_turnaround":"PASS",
        "check_assumed_successor_turnaround_and_berth_movement":"PASS",
        "check_service_spacing_at_baseline":"PASS",
        "headway_rule":"abs(shift_j - shift_(j-1)) <= 5 min; fixed previous/next trip shifts=0",
        "headway_before_or_after_window":"baseline anchor assumed fixed; exact preceding source time not independently checked",
        "feasible_integer_minute_shift_vectors":count,
        "example_feasible_nonzero_shift_vector":first_nonzero,
        "sensitivity_baseline_feasibility":scenario_checks,
        "all_stated_individual_shift_values_attainable_in_some_feasible_combination":True,
        "limitations":[
            "Inputs transcribed from previous extraction summary; original ZIP unavailable in this session.",
            "This is a six-trip vehicle-gap and headway consistency check, not a full block/crew/berth operational certification.",
            "Berth movement, turnaround, transfer and headway values are declared assumptions; sensitivities not yet solved.",
            "Scope B observed vehicle feasibility and timestamp validation remain open.",
            "Historical GTFS corrected-archive reconciliation remains open."
        ]
    }
    (OUT/"model_assumptions_and_checks.json").write_text(json.dumps(detail,indent=2)+"\n",encoding="utf-8")
    print("Original timetable feasible under agreed modeled rules: YES")
    print("Vehicle bounds confirmed: ",[(r['earliest_shift_min'],r['latest_shift_min']) for r in rows])
    print("Feasible joint integer-minute shift vectors:",count)
    print("All individual bounds attainable in a jointly feasible vector: YES")
    print("5-min turnaround + 2-min berth reposition baseline feasible:",admissible((0,)*6,turn=5,reposition=2))

def clockshift(s, delta):
    hh,mm=map(int,s.split(':'));v=hh*60+mm+delta
    return f'{v//60:02d}:{v%60:02d}'

if __name__=='__main__':main()
