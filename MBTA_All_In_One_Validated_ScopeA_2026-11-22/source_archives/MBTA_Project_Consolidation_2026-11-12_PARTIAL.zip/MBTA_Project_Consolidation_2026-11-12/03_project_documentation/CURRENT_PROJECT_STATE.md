# Current project state — November 12, 2026

## Evidence boundaries

This document consolidates existing decisions and reported findings; it is **not a new extraction, optimization run, or independent model validation**. The current v2 report and revision notes are physically included and unchanged. The older code/data archives are listed in `../PACKAGE_STATUS.json`; their absence from this bundle does not establish that the earlier calculations were wrong, but it prevents rerunning them from this bundle alone.

## Scope, team and schedule

**Team:** Alex Lim, Yun Ji Seo, Luran Wang. **Deliverable stage:** one-page interim report, not the final technical report. **Interim due date:** November 13, 2026, as reported by the team; the supplied course brief still lists the original November 6 date. **Study:** scheduled arrivals on Routes 22 and 23 at Ashmont from 16:00 up to (not including) 19:00 on October 15, 2026, transferring to Route 215 toward Quincy Center.

Scope A is the committed deterministic study. Scope B remains a conditional extension with one shared timetable across scheduled, representative-delay and disrupted-delay scenarios, minimizing the largest scenario-average waiting cost. It is not a model that selects a new timetable after observing delays.

## Latest report and code versions

The November 12 v2 interim DOCX/PDF/Markdown are the current report. Older November 6 report drafts are superseded for reading/submission preparation but should be preserved in their original archives.

The original full model is the November 6 package, with `src/run_scope_a.jl`, the Python reference implementations and the archived-data CSV inputs. That full package is **not currently included**. The November 12 patcher is an additional, non-destructive code change set. It is **not the complete Julia model** and has not been applied to the actual original source in this consolidation. Julia execution remains pending; the previously reported Python/SciPy results do not substitute for a Julia execution test.

## Working assumptions already agreed

| Item | Working specification | Evidence/status |
|---|---|---|
| Passenger walking/boarding allowance | 3 minutes; consider 2 and 5 in sensitivity | Study assumption, repeated in report v2 |
| Scheduled vehicle turnaround | 3 minutes | Study assumption, not MBTA certification |
| Different Quincy berth movement | 2 additional minutes | Study assumption, not measured movement time |
| Departure retiming | At most ±5 minutes in one-minute increments, with tighter vehicle bounds | Model design choice |
| Headways | At most ±5 minutes from original headways, including fixed boundary services | Model design choice |
| Transfer catch rule | Earliest eligible departure at or after arrival plus allowance | Existing model rule |
| Late-window transfers | Retain onward service after 19:00 | Existing model rule |
| Weighting | One equal weight per incoming-trip opportunity | Not measured passenger demand |
| Full selected trip | Shift every scheduled stop time consistently | Routes, trips and running times otherwise fixed |
| Genuinely no onward service | Previously adopted 60-minute cost; never an optional substitute for available service | Conversation/closure decision; unused in reported cohort |

This is a human-readable summary, **not a reconstructed substitute for `adopted_scope_a_config.json`**. Earlier research defaults included a different stranded penalty; use the reconciled adopted config when the original archive is restored.

## Recorded preliminary results

Source: the included report v2 and revision notes, which refer to the earlier November 6 calculation records. The underlying saved result JSON/CSV files are **not included until that model archive is restored**.

| Quantity | Reported value |
|---|---|
| Incoming opportunities | 41: 18 from Route 22, 23 from Route 23 |
| Adjustable departures | 6 |
| All-day eligible onward departures | 37, including 10 after 19:00 |
| Mean waiting after allowance | 13.51 minutes original; 12.46 minutes modeled optimum |
| Mean reduction | 1.05 minutes per opportunity; 7.76% of post-allowance waiting |
| Maximum waiting after allowance | 30 minutes original; 27 minutes modeled optimum |
| Waiting at most ten minutes | 15/41 original; 20/41 modeled optimum |
| Direction of individual changes | 18 improve, 7 worsen, 16 unchanged |
| Changed departures | 16:20→16:18; 17:20→17:18; 17:50→17:49; 18:20→18:22 |
| Unchanged selected departures | 16:50 and 18:52 |
| Computation reported earlier | Enumeration of 71,673 feasible integer-minute timetables; SciPy/HiGHS agrees |
| Julia status | Source prepared; execution pending |

The reported 7.76% is not a reduction in total journey time or a ridership-weighted passenger benefit. Small modeled shifts are candidates for planning review, not a deployment recommendation. No new heuristic, sensitivity results or Scope B results are claimed here.

## Validation history and pending work

Earlier conversation records report that Scope A historical reconciliation and raw-to-prepared reproducibility were completed for the selected October 15 study records. The reports and source archives must be restored before those claims can be independently rechecked from this bundle.

Pending Scope A work: restore the full package; apply/review runtime edits; execute Julia and preserve solver status; compare with a simple feasible retiming rule; run consistent sensitivity analyses with rebuilt bounds and constraints. Actual MBTA operating requirements remain assumptions/limitations.

When Scope B resumes, revisit: date-specific timetable matching, the four-hour planned/observed timestamp discrepancy, missing/ambiguous observations, declared scenario-selection rules, and delayed vehicle availability including Quincy terminal endpoints. Do not treat preliminary bus events as finalized delay scenarios.

## Milestones

| Date/window | Existing plan/status |
|---|---|
| Oct 23–29 | Scope A preparation milestone reported complete under stated assumptions |
| Nov 6 | Initial model/formulation and interim draft prepared in the earlier package |
| Nov 12 | Interim report revised; static code-safety patch supplied |
| Nov 13 | Revised interim deadline reported by team |
| Nov 7–15 | Julia validation, heuristic comparison and Scope A checks |
| Nov 16–22 | Interpretation and optional Scope B, conditional on validation |
| Nov 23–30 | Planned final-report/slides drafting; not delivered here |
| Dec 1–6 | Planned final verification and presentation preparation |
| Dec 7 | Final submissions per supplied course brief |
| Dec 9–10 | Presentations per supplied course brief; section dependent |
