# Interim report revision — November 12, 2026

## Deliverable scope

The report remains a one-page interim progress report, not the final technical report. The governing brief's page 5 asks for problem description, data, methods, expected results, and practical implications. The due date shown is November 13, 2026, reflecting the extension reported by the team; the original PDF brief still says November 6.

The earlier DOCX, PDF, full model ZIP, and input CSVs are not mounted in the current processing environment. This revision was rebuilt from the full earlier draft and calculation records preserved in the conversation. It retains the numerical findings rather than implying a new solver run or historical-data audit. Julia execution remains pending.

## Changes to the report

| Requested improvement | Revision made |
|---|---|
| Clarify the population and operating scenario | Explicitly states October 15, 4–7 p.m., on-time operation, and equally weighted incoming-trip opportunities rather than passenger counts. |
| Improve preliminary-results interpretation | Gives both the 1.05-minute absolute decrease and 7.76% relative decrease, specifically for waiting after the transfer allowance. |
| Maintain a compact results table | Retains mean waiting, maximum waiting, and opportunities waiting no longer than ten minutes. The last metric is a descriptive reporting threshold, not a claimed MBTA standard. |
| Explain the actual timetable change | Names the four changed departure times; the 16:50 and 18:52 departures remain unchanged. |
| Acknowledge unequal benefits | States 18 opportunities improve, 7 worsen, and 16 do not change. |
| Strengthen practical implications | Describes candidate changes for operational review, with no claim of deployment readiness, zero cost, or systemwide passenger gains. |
| Preserve accurate implementation status | Attributes the existing computational result to Python enumeration and SciPy/HiGHS; Julia/JuMP execution remains pending. |
| Distinguish findings from expected work | Heuristic comparison and sensitivity analysis remain next steps; their future outcomes are not predicted or invented. |
| Keep the interim scope compact | Omits unused stranded-penalty details, extensive archive history, full equations, and final-report material. Scope B remains deferred. |
| Retain sources | Includes a brief source note for the historical GTFS and the recorded computational outputs. |

## Arithmetic checked in this revision

These checks use the earlier reported aggregates, not a new extraction or optimization:

- Baseline total post-allowance waiting: 554 minutes across 41 opportunities.
- Optimized total: 511 minutes across the same 41 opportunities.
- Means: 554/41 = 13.512195 minutes; 511/41 = 12.463415 minutes.
- Absolute improvement: 43/41 = 1.048780 minutes per opportunity.
- Relative improvement: 43/554 × 100 = 7.761733%.
- Direction of change: 18 + 7 + 16 = 41 opportunities.
- Changed departures: 16:20→16:18, 17:20→17:18, 17:50→17:49, 18:20→18:22; each changes by at most two minutes.

The 7.76% refers to waiting after the allowance, not total journey time. Adding a three-minute transfer allowance changes total modeled transfer means to 16.512195 and 15.463415 minutes; that percentage reduction would be 6.351551%. The report avoids substituting one metric for the other.

## Code-review material

`code/apply_runtime_fixes.py` is a narrowly scoped patcher for the matching source listing from the previous model package. It preserves comments and provenance and addresses explicit clock-field parsing, solver-status recording, and evaluation of time-limited incumbents. It is not a replacement model or a tested Julia implementation. See `notes/Code_Review.md` for its assumptions and application instructions.

## Package contents

- `MBTA_Interim_Report_v2_2026-11-12.docx`: editable, one-page revision.
- `MBTA_Interim_Report_v2_2026-11-12.pdf`: rendered review/submission-format copy.
- `MBTA_Interim_Report_v2_2026-11-12.md`: the same report content in text form.
- `notes/Revision_Notes.md`: this change summary and evidence limitations.
- `notes/Code_Review.md`: static source review and targeted changes.
- `notes/patch_checks.json`: text-patch tests only; no Julia execution.
- `code/apply_runtime_fixes.py`: optional non-destructive patcher for the old source.

This ZIP supplements the earlier model package. It does not contain the original GTFS, input tables, or full solver project, and it does not replace those archives.
