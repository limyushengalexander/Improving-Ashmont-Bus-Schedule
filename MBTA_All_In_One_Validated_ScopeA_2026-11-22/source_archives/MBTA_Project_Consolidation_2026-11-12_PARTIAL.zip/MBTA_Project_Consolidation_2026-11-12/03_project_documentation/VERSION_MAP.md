# Version map and precedence

| Component | Use as current | Preserve as history | Availability in this delivery |
|---|---|---|---|
| Interim report | November 12, 2026 v2 DOCX/PDF/Markdown | November 6 draft | v2 present; November 6 model archive missing |
| Julia model | November 6 full source plus November 12 reviewed runtime edits, after application and execution checks | Original source unchanged | Patcher only present; no full `.jl` solver |
| Python reference model | November 6 enumeration and SciPy/HiGHS code | Original run logs | Full model archive missing |
| Solver-ready Scope A data | Frozen `inputs/` in November 6 model package; compare with adopted historical extraction | October 31 prepared snapshot | Both source archives currently missing |
| Historical schedule source | `20261014.zip` for the reconciled study | Original starter snapshot | Both missing |
| Operating configuration | Adopted/reconciled Scope A config with 60-minute stranded cost and two-minute different-berth movement | Research-kit defaults | Original config file missing; decisions summarized only |
| Waiting/optimization results | Original saved calculation outputs in November 6 model package | Earlier baselines and audits | Summarized in report only; result files missing |
| Code revision | `02_code_updates/apply_runtime_fixes.py` and its supplied review notes | Original source blocks | Present unchanged; not applied here |
| Scope B observations | Original starter event extract and prepared-data event audits | Earlier exploratory diagnostics | Missing and still provisional |
| Requirements | Attached `Term project description.pdf` | No replacement created | Present byte-for-byte; deadline extension recorded separately |

## Do not silently reconcile these differences

The report v2 supersedes the wording in the initial one-page draft; it does not replace raw data or solver results. The code patch does not create a full solver project. Historical reconciliation concerns a specific October 15 cohort and is not validation for every Scope B observation date. The revised November 13 interim deadline comes from the user, not an edited course PDF. Old defaults must not override the adopted model configuration.

All original provenance comments and revision limitations remain intact. No report, data or solver output has been relabeled as newly computed.
