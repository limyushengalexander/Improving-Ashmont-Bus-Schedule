# Original packages

This directory keeps original ZIP files unchanged as source records. At assembly time only the November 12 interim revision ZIP is available. The expected earlier archives are listed in `../PACKAGE_STATUS.json` and `../03_project_documentation/expected_packages.json`.

`tools/collect_previous_packages.py` can copy locally saved older archives here, verify their ZIP integrity, update the inventory and create a new combined ZIP. It does not fabricate missing inputs, extract untrusted paths, modify models, apply patches, or run optimization.
