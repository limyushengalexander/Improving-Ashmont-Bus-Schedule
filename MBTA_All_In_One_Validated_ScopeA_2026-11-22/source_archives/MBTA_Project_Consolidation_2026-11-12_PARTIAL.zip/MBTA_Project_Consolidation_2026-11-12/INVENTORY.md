# Latest project inventory

As of **2026-11-12**. **Partial consolidation — original code/data archives missing.**

## Available current files

| Path | Role |
|---|---|
| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.docx` | Current editable one-page interim report |
| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.pdf` | Current one-page PDF; unchanged source copy |
| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.md` | Same report content in Markdown |
| `02_code_updates/apply_runtime_fixes.py` | Non-destructive patcher, not a full Julia solver |
| `02_code_updates/Code_Review.md` | Static code-review findings and patch instructions |
| `03_project_documentation/Revision_Notes_v2.md` | Changes and evidence limits from report revision |
| `03_project_documentation/CURRENT_PROJECT_STATE.md` | Consolidated decisions and recorded results, not a new run |
| `03_project_documentation/VERSION_MAP.md` | Which versions take precedence |
| `04_course_requirements/Term_project_description.pdf` | Original uploaded requirement document |
| `06_integrity/` | Hashes, copy provenance, and available validation records |
| `tools/collect_previous_packages.py` | Optional local restoration and bundle builder |
| `tools/verify_manifest.py` | Verify every packaged file against recorded SHA-256 hashes |

## Source archive inventory

| Original archive | Status | Contents/purpose |
|---|---|---|
| `MBTA_Interim_Report_Revision_v2_2026-11-12.zip` | **INCLUDED** | Latest interim report, runtime-safety patcher, revision and code-review notes |
| `MBTA_ScopeA_Nov06_Model_and_Interim_Report.zip` | **MISSING** | Full initial model, Julia project, Python enumeration/MILP, input CSVs, saved results, tests and mathematical formulation |
| `20261014.zip` | **MISSING** | Raw historical GTFS archive used for the October 15 study |
| `MBTA_Ashmont_Project_Starter_2026-10-16 (1).zip` | **MISSING** | Original GTFS snapshot and raw Ashmont bus-event observations |
| `MBTA_Ashmont_Prepared_Data_2026-10-31.zip` | **MISSING** | Earlier cleaned schedule tables, baseline, vehicle chains and preliminary event audits |
| `MBTA_Ashmont_Research_and_Preparation_Kit_2026-10-31.zip` | **MISSING** | Data preparation and event-audit scripts, source documentation and tests |
| `MBTA_ScopeA_Oct23-29_Closure.zip` | **MISSING** | Agreed assumptions, individual shift bounds and vehicle/headway consistency checks |
| `MBTA_Historical_GTFS_Reconciliation_2026-11-06.zip` | **MISSING** | Archived Scope A extraction, adopted configuration, historical comparisons and validation scripts |

### Missing working material (do not mistake summaries for files)

Until the corresponding original archives are included and extracted, the following are references rather than bundled working files:

- Full `run_scope_a.jl`, `Project.toml`, Python enumeration/MILP implementations and original tests.
- The 41-row incoming table, 37-row onward table, complete-trip stop times, vehicle links, headway bounds, adopted configuration and shift bounds.
- Original enumeration/SciPy result JSONs, row-level comparisons and solver/test logs.
- Raw historical GTFS, original snapshot, event Parquet, preparation scripts and historical reconciliation records.

These are not reconstructed from prose or replaced with invented CSVs. Once archives are restored, preserve their native internal paths. The original code patch should be applied only to its recognized source version.

## Additional historical references

The earlier standalone `FRESH_REPRODUCIBILITY_CHECK_2026-11-06.md`, syllabus, lecture PDFs and local screenshot inventory are not mounted at the initial consolidation. They are not embedded here. The later historical reconciliation package is separately requested above. Course slides are optional references for reproducing Scope A.

## Scope restrictions

The interim report is current; no final technical report, slides or video is created. Julia execution, heuristic comparison, sensitivity analysis and Scope B validation remain pending. Copying an archive into this bundle does not change those statuses.
