# MBTA Ashmont — latest project consolidation

**Release:** 2026-11-12 | **Team:** Alex Lim, Yun Ji Seo, Luran Wang  
**Stage:** interim report; not the final report  
**Coverage:** Partial consolidation — original code/data archives missing

## Start here

Open `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.pdf` for the current one-page report. Use the DOCX beside it for edits. `INVENTORY.md` lists the latest known code, data and documentation and says which files are actually present. `PACKAGE_STATUS.json` is the machine-readable availability record.

The currently included report files, code patcher and source notes are unchanged from the November 12 v2 ZIP. The source ZIP is retained under `05_prior_packages/`. New inventory/project-state documents are clearly labeled summaries; they are not substitute datasets, configurations or computational results.

**Important:** Only 1 of 8 expected source archives are included. When this count is incomplete, this is **not a self-contained reproducibility package**. There is no complete Julia model or raw/model-input dataset unless its original archive is present and extracted. The available patcher is not a replacement for those files.

## Directory guide

```text
01_current_interim/          Latest v2 report: DOCX, PDF and Markdown
02_code_updates/             Latest runtime-safety patcher and static review
03_project_documentation/    Project state, assumptions summary, revisions and versions
04_course_requirements/      Original term-project description
05_prior_packages/           Original ZIPs, preserved unchanged
06_integrity/                Hash and provenance checks
 tools/                      Local restoration and verification utilities
```

## Missing archives

- `MBTA_ScopeA_Nov06_Model_and_Interim_Report.zip`
- `20261014.zip`
- `MBTA_Ashmont_Project_Starter_2026-10-16 (1).zip`
- `MBTA_Ashmont_Prepared_Data_2026-10-31.zip`
- `MBTA_Ashmont_Research_and_Preparation_Kit_2026-10-31.zip`
- `MBTA_ScopeA_Oct23-29_Closure.zip`
- `MBTA_Historical_GTFS_Reconciliation_2026-11-06.zip`

The first priority for restoring the full working model is `MBTA_ScopeA_Nov06_Model_and_Interim_Report.zip`. The other archives recover raw sources, processing history and Scope B's preliminary observations. Previously downloading or attaching a file does not make its bytes part of this new ZIP.

## Restore local copies into one ZIP (optional)

Put the named older ZIPs in one directory. From the extracted consolidation folder, run:

```bash
python tools/collect_previous_packages.py --from-dir "/path/to/saved/project_zips"
python tools/verify_manifest.py
```

The collector accepts the starter ZIP with or without ` (1)` in its filename. It verifies ZIP integrity, copies originals unchanged into `05_prior_packages`, updates the inventory, and creates a new combined ZIP **beside** this folder. It writes a `_PARTIAL` filename while any required archive remains missing. It does not alter the original source files, apply code patches, run optimization or validate Julia.

If the source records are uploaded back into this conversation, they can instead be merged into the same structure here. The present package does not claim they were recovered.

## Current conclusions and unfinished work

The v2 report records the prior 13.51-to-12.46-minute modeled mean-wait improvement under the adopted assumptions. No new result is computed during packaging. The full model's saved results and inputs must be restored before that result can be rerun from this bundle. Julia execution remains pending; the latest code addition is a non-destructive patch only. Heuristic/sensitivity work is still planned. Scope B stays deferred with its timestamp, historical schedule and vehicle-availability checks open.

See `03_project_documentation/CURRENT_PROJECT_STATE.md` for the summarized assumptions, reported findings and timeline, and `VERSION_MAP.md` for superseded files. Those notes describe the state at initial assembly; consult the refreshed `PACKAGE_STATUS.json` for later restoration status.
