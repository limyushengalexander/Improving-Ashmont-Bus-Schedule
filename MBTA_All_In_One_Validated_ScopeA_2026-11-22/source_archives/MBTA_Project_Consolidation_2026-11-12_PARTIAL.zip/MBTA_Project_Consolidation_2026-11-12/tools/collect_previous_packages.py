#!/usr/bin/env python3
"""Collect the project's existing ZIPs into one indexed, checksummed bundle.

This is packaging only. No model, dataset, or result is reconstructed or changed.
Only explicitly named archives are copied; they remain compressed and unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path
from zipfile import BadZipFile, ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
AS_OF = "2026-11-12"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_zip(path: Path) -> int:
    """Check readable central directory and all member CRCs without extracting."""
    with ZipFile(path) as archive:
        if sum(x.file_size for x in archive.infolist()) > 4 * 1024**3:
            raise ValueError(f"Archive exceeds the 4 GiB inspection limit: {path.name}")
        if any(x.flag_bits & 1 for x in archive.infolist()):
            raise ValueError(f"Encrypted archive is unsupported: {path.name}")
        bad = archive.testzip()
        if bad is not None:
            raise ValueError(f"CRC check failed in {path.name}: {bad}")
        return len([x for x in archive.infolist() if not x.is_dir()])


def locate(spec: dict, directories: list[Path]) -> Path | None:
    for directory in directories:
        for name in [spec["filename"], *spec.get("aliases", [])]:
            candidate = directory / name
            if candidate.is_file():
                return candidate
    return None


def payload_files() -> list[Path]:
    return sorted(
        f for f in ROOT.rglob("*")
        if f.is_file() and "__pycache__" not in f.parts
        and f.suffix not in {".pyc", ".tmp"}
        and f.name != "manifest_sha256.json"
    )


def refresh_indices() -> dict:
    expected = json.loads(
        (ROOT / "03_project_documentation/expected_packages.json").read_text(encoding="utf-8")
    )["packages"]
    records = []
    for spec in expected:
        p = ROOT / "05_prior_packages" / spec["filename"]
        record = dict(spec)
        record["status"] = "included" if p.is_file() else "missing"
        record["archive_path"] = str(p.relative_to(ROOT)) if p.is_file() else None
        if p.is_file():
            record.update(bytes=p.stat().st_size, sha256=sha256(p), zip_members=validate_zip(p))
        records.append(record)
    missing = [r["filename"] for r in records
               if r["required_for_full_history"] and r["status"] != "included"]
    complete = not missing
    status = {
        "release_as_of": AS_OF,
        "source_coverage": "COMPLETE_EXPECTED_ARCHIVES" if complete else "PARTIAL_MISSING_SOURCE_ARCHIVES",
        "expected_archives": len(records),
        "included_archives": sum(r["status"] == "included" for r in records),
        "missing_archives": missing,
        "packages": records,
        "current_report": "01_current_interim/MBTA_Interim_Report_v2_2026-11-12.pdf",
        "current_code_update": "02_code_updates/apply_runtime_fixes.py",
        "patch_applied_by_collector": False,
        "optimization_run_by_collector": False,
        "julia_execution": "PENDING; this packaging tool does not execute Julia",
        "scope_b": "DEFERRED; preliminary events are not validated scenarios",
        "completeness_definition": "Archive availability only; not certification of model execution, sensitivity results, or real operating requirements."
    }
    (ROOT / "PACKAGE_STATUS.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
    state = "Complete expected-archive collection" if complete else "Partial consolidation — original code/data archives missing"
    rows = [
        "# Latest project inventory", "", f"As of **{AS_OF}**. **{state}.**", "",
        "## Available current files", "",
        "| Path | Role |", "|---|---|",
        "| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.docx` | Current editable one-page interim report |",
        "| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.pdf` | Current one-page PDF; unchanged source copy |",
        "| `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.md` | Same report content in Markdown |",
        "| `02_code_updates/apply_runtime_fixes.py` | Non-destructive patcher, not a full Julia solver |",
        "| `02_code_updates/Code_Review.md` | Static code-review findings and patch instructions |",
        "| `03_project_documentation/Revision_Notes_v2.md` | Changes and evidence limits from report revision |",
        "| `03_project_documentation/CURRENT_PROJECT_STATE.md` | Consolidated decisions and recorded results, not a new run |",
        "| `03_project_documentation/VERSION_MAP.md` | Which versions take precedence |",
        "| `04_course_requirements/Term_project_description.pdf` | Original uploaded requirement document |",
        "| `06_integrity/` | Hashes, copy provenance, and available validation records |",
        "| `tools/collect_previous_packages.py` | Optional local restoration and bundle builder |",
        "| `tools/verify_manifest.py` | Verify every packaged file against recorded SHA-256 hashes |",
        "", "## Source archive inventory", "",
        "| Original archive | Status | Contents/purpose |", "|---|---|---|",
    ]
    for r in records:
        rows.append(f"| `{r['filename']}` | **{r['status'].upper()}** | {r['purpose']} |")
    rows += ["", "### Missing working material (do not mistake summaries for files)", "",
             "Until the corresponding original archives are included and extracted, the following are references rather than bundled working files:", "",
             "- Full `run_scope_a.jl`, `Project.toml`, Python enumeration/MILP implementations and original tests.",
             "- The 41-row incoming table, 37-row onward table, complete-trip stop times, vehicle links, headway bounds, adopted configuration and shift bounds.",
             "- Original enumeration/SciPy result JSONs, row-level comparisons and solver/test logs.",
             "- Raw historical GTFS, original snapshot, event Parquet, preparation scripts and historical reconciliation records.",
             "", "These are not reconstructed from prose or replaced with invented CSVs. Once archives are restored, preserve their native internal paths. The original code patch should be applied only to its recognized source version.",
             "", "## Additional historical references", "",
             "The earlier standalone `FRESH_REPRODUCIBILITY_CHECK_2026-11-06.md`, syllabus, lecture PDFs and local screenshot inventory are not mounted at the initial consolidation. They are not embedded here. The later historical reconciliation package is separately requested above. Course slides are optional references for reproducing Scope A.",
             "", "## Scope restrictions", "",
             "The interim report is current; no final technical report, slides or video is created. Julia execution, heuristic comparison, sensitivity analysis and Scope B validation remain pending. Copying an archive into this bundle does not change those statuses.", ""]
    (ROOT / "INVENTORY.md").write_text("\n".join(rows), encoding="utf-8")
    missing_block = "\n".join(f"- `{name}`" for name in missing) or "None of the expected core archives is missing."
    readme = f"""# MBTA Ashmont — latest project consolidation

**Release:** {AS_OF} | **Team:** Alex Lim, Yun Ji Seo, Luran Wang  
**Stage:** interim report; not the final report  
**Coverage:** {state}

## Start here

Open `01_current_interim/MBTA_Interim_Report_v2_2026-11-12.pdf` for the current one-page report. Use the DOCX beside it for edits. `INVENTORY.md` lists the latest known code, data and documentation and says which files are actually present. `PACKAGE_STATUS.json` is the machine-readable availability record.

The currently included report files, code patcher and source notes are unchanged from the November 12 v2 ZIP. The source ZIP is retained under `05_prior_packages/`. New inventory/project-state documents are clearly labeled summaries; they are not substitute datasets, configurations or computational results.

**Important:** Only {status['included_archives']} of {len(records)} expected source archives are included. When this count is incomplete, this is **not a self-contained reproducibility package**. There is no complete Julia model or raw/model-input dataset unless its original archive is present and extracted. The available patcher is not a replacement for those files.

## Directory guide

```text
01_current_interim/          Latest v2 report: DOCX, PDF and Markdown
02_code_updates/             Latest runtime-safety patcher and static review
03_project_documentation/    Project state, assumptions summary, revisions and versions
04_course_requirements/      Original term-project description
05_prior_packages/           Original ZIPs, preserved unchanged
06_integrity/                Hash and provenance checks
 tools/                      Local restoration and verification utilities
```

## Missing archives

{missing_block}

The first priority for restoring the full working model is `MBTA_ScopeA_Nov06_Model_and_Interim_Report.zip`. The other archives recover raw sources, processing history and Scope B's preliminary observations. Previously downloading or attaching a file does not make its bytes part of this new ZIP.

## Restore local copies into one ZIP (optional)

Put the named older ZIPs in one directory. From the extracted consolidation folder, run:

```bash
python tools/collect_previous_packages.py --from-dir "/path/to/saved/project_zips"
python tools/verify_manifest.py
```

The collector accepts the starter ZIP with or without ` (1)` in its filename. It verifies ZIP integrity, copies originals unchanged into `05_prior_packages`, updates the inventory, and creates a new combined ZIP **beside** this folder. It writes a `_PARTIAL` filename while any required archive remains missing. It does not alter the original source files, apply code patches, run optimization or validate Julia.

If the source records are uploaded back into this conversation, they can instead be merged into the same structure here. The present package does not claim they were recovered.

## Current conclusions and unfinished work

The v2 report records the prior 13.51-to-12.46-minute modeled mean-wait improvement under the adopted assumptions. No new result is computed during packaging. The full model's saved results and inputs must be restored before that result can be rerun from this bundle. Julia execution remains pending; the latest code addition is a non-destructive patch only. Heuristic/sensitivity work is still planned. Scope B stays deferred with its timestamp, historical schedule and vehicle-availability checks open.

See `03_project_documentation/CURRENT_PROJECT_STATE.md` for the summarized assumptions, reported findings and timeline, and `VERSION_MAP.md` for superseded files. Those notes describe the state at initial assembly; consult the refreshed `PACKAGE_STATUS.json` for later restoration status.
"""
    (ROOT / "README_FIRST.md").write_text(readme, encoding="utf-8")
    files = payload_files()
    manifest = [{"path": str(f.relative_to(ROOT)), "bytes": f.stat().st_size, "sha256": sha256(f)}
                for f in files]
    (ROOT / "manifest_sha256.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return status


def write_bundle(output: Path, force: bool) -> int:
    output = output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError("Output ZIP must be outside the source folder to avoid recursive packaging.")
    if output.exists() and not force:
        raise FileExistsError(f"Refusing to replace {output}; use a new path or --replace-output.")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=output.parent, suffix=".zip", delete=False) as temp:
        temporary = Path(temp.name)
    try:
        with ZipFile(temporary, "w", ZIP_DEFLATED, compresslevel=6) as archive:
            for f in sorted(ROOT.rglob("*")):
                if f.is_file() and "__pycache__" not in f.parts and f.suffix not in {".pyc", ".tmp"}:
                    archive.write(f, f"{ROOT.name}/{f.relative_to(ROOT).as_posix()}")
        members = validate_zip(temporary)
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{sha256(output)}  {output.name}\n", encoding="utf-8")
    return members


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-dir", action="append", type=Path, default=[],
                        help="Directory holding saved original ZIPs; may be repeated; no recursive search")
    parser.add_argument("--output", type=Path, help="ZIP outside this folder; defaults beside it")
    parser.add_argument("--replace-output", action="store_true", help="Replace only the generated output ZIP")
    args = parser.parse_args()
    directories = [p.expanduser().resolve() for p in args.from_dir]
    for d in directories:
        if not d.is_dir():
            parser.error(f"Source directory does not exist: {d}")
    expected = json.loads((ROOT / "03_project_documentation/expected_packages.json").read_text())["packages"]
    copied = []
    for spec in expected:
        src = locate(spec, directories)
        if src is None:
            continue
        dst = ROOT / "05_prior_packages" / spec["filename"]
        validate_zip(src)
        if dst.exists():
            if sha256(src) != sha256(dst):
                raise ValueError(f"Different bytes for existing {dst.name}; no overwrite performed.")
            continue
        tmp = dst.with_name(dst.name + ".tmp")
        try:
            shutil.copyfile(src, tmp)
            if sha256(tmp) != sha256(src):
                raise ValueError(f"Copy hash failed for {src.name}")
            tmp.replace(dst)
        finally:
            tmp.unlink(missing_ok=True)
        copied.append(dst.name)
    status = refresh_indices()
    suffix = "_PARTIAL" if status["missing_archives"] else "_SOURCE_ARCHIVES_RESTORED"
    output = args.output or ROOT.parent / (ROOT.name + suffix + ".zip")
    members = write_bundle(output, args.replace_output)
    print(f"Copied {len(copied)} archives; {status['included_archives']}/{status['expected_archives']} expected archives included.")
    for name in status["missing_archives"]:
        print(f"MISSING: {name}")
    print(f"Wrote {output} ({members} files). ZIP CRC and file-copy hashes checked.")
    print("No model or Julia execution performed; code patch not applied.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, BadZipFile) as exc:
        print(f"Packaging failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
