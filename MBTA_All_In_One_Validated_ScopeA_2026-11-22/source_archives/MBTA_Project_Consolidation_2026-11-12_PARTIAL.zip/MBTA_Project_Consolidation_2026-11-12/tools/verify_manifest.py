#!/usr/bin/env python3
"""Verify packaged bytes only. This does not validate model results."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
manifest = ROOT / "manifest_sha256.json"
if not manifest.is_file():
    raise SystemExit("manifest_sha256.json is missing.")
records = json.loads(manifest.read_text(encoding="utf-8"))
errors = []
for record in records:
    target = (ROOT / record["path"]).resolve()
    if ROOT not in target.parents or not target.is_file():
        errors.append(f"Missing or invalid path: {record['path']}")
        continue
    digest = hashlib.sha256()
    with target.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != record["sha256"] or target.stat().st_size != record["bytes"]:
        errors.append(f"Modified bytes: {record['path']}")
if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
status = json.loads((ROOT / "PACKAGE_STATUS.json").read_text(encoding="utf-8"))
print(f"Verified {len(records)} files against SHA-256 and byte counts.")
print(f"Source archives: {status['included_archives']}/{status['expected_archives']} included.")
print(f"Coverage: {status['source_coverage']}")
print("File integrity is not proof of model or Julia execution.")
